import type { User, SubjectGrade, Activity, CalendarEvent, LeaderboardEntry, Goal, Cosmetic, GrimReaperChallenge, Friend } from '@/types';

export const mockUser: User = {
  id: '1',
  username: 'Alex Pratama',
  handle: '@alexpratama',
  email: 'alex@example.com',
  role: 'student',
  grade: '12',
  class: 'A',
  level: 24,
  xp: 2450,
  xpToNextLevel: 3000,
  coins: 500,
  rank: 12,
  streak: 7,
  friendsCount: 45,
  profileVisible: true,
  avatarLetter: 'A',
  createdAt: '2024-09-01',
};

export const mockSubjectGrades: SubjectGrade[] = [
  {
    subject: 'Mathematics',
    currentScore: 85,
    previousScore: 82,
    change: 3,
    target: 85,
    predictedScore: 90,
    history: [
      { month: 'Jan', score: 78 },
      { month: 'Feb', score: 82 },
      { month: 'Mar', score: 80 },
      { month: 'Apr', score: 85 },
      { month: 'May', score: 85 },
    ],
  },
  {
    subject: 'Physics',
    currentScore: 78,
    previousScore: 80,
    change: -2,
    target: 85,
    predictedScore: 80,
    history: [
      { month: 'Jan', score: 75 },
      { month: 'Feb', score: 78 },
      { month: 'Mar', score: 80 },
      { month: 'Apr', score: 78 },
      { month: 'May', score: 78 },
    ],
  },
  {
    subject: 'Chemistry',
    currentScore: 92,
    previousScore: 87,
    change: 5,
    target: 90,
    predictedScore: 95,
    history: [
      { month: 'Jan', score: 85 },
      { month: 'Feb', score: 88 },
      { month: 'Mar', score: 87 },
      { month: 'Apr', score: 90 },
      { month: 'May', score: 92 },
    ],
  },
  {
    subject: 'Biology',
    currentScore: 88,
    previousScore: 87,
    change: 1,
    target: 85,
    predictedScore: 90,
    history: [
      { month: 'Jan', score: 82 },
      { month: 'Feb', score: 85 },
      { month: 'Mar', score: 86 },
      { month: 'Apr', score: 87 },
      { month: 'May', score: 88 },
    ],
  },
  {
    subject: 'English',
    currentScore: 75,
    previousScore: 71,
    change: 4,
    target: 80,
    predictedScore: 78,
    history: [
      { month: 'Jan', score: 70 },
      { month: 'Feb', score: 72 },
      { month: 'Mar', score: 71 },
      { month: 'Apr', score: 73 },
      { month: 'May', score: 75 },
    ],
  },
  {
    subject: 'IT',
    currentScore: 82,
    previousScore: 82,
    change: 0,
    target: 85,
    predictedScore: 84,
    history: [
      { month: 'Jan', score: 78 },
      { month: 'Feb', score: 80 },
      { month: 'Mar', score: 81 },
      { month: 'Apr', score: 82 },
      { month: 'May', score: 82 },
    ],
  },
];

export const mockActivities: Activity[] = [
  {
    id: '1',
    type: 'grade-increase',
    title: 'Grade Increased!',
    description: 'Mathematics: 78 → 85',
    timestamp: '2 hours ago',
    reward: { type: 'xp', amount: 50 },
  },
  {
    id: '2',
    type: 'achievement',
    title: 'Achievement Unlocked',
    description: 'Perfect Score in Chemistry',
    timestamp: '5 hours ago',
    reward: { type: 'coins', amount: 100 },
  },
  {
    id: '3',
    type: 'purchase',
    title: 'Item Purchased',
    description: 'Emerald Gem - Rare',
    timestamp: '1 day ago',
    reward: { type: 'coins', amount: -250 },
  },
  {
    id: '4',
    type: 'target-achieved',
    title: 'Target Achieved',
    description: 'Physics reached target of 80',
    timestamp: '2 days ago',
    reward: { type: 'xp', amount: 75 },
  },
  {
    id: '5',
    type: 'friend-added',
    title: 'New Friend',
    description: 'Sarah joined as a friend',
    timestamp: '3 days ago',
  },
];

export const mockEvents: CalendarEvent[] = [
  {
    id: '1',
    title: 'Midterm Exam',
    subject: 'Mathematics',
    type: 'exam',
    date: 'Dec 15, 2025',
    time: '08:00',
    daysLeft: 12,
  },
  {
    id: '2',
    title: 'Chapter 5 Quiz',
    subject: 'Physics',
    type: 'quiz',
    date: 'Dec 10, 2025',
    time: '10:30',
    daysLeft: 7,
  },
  {
    id: '3',
    title: 'Lab Assignment',
    subject: 'Chemistry',
    type: 'assignment',
    date: 'Dec 8, 2025',
    time: '14:00',
    daysLeft: 5,
  },
];

export const mockLeaderboard: LeaderboardEntry[] = [
  { rank: 1, userId: '2', username: 'Sarah Williams', avatarLetter: 'S', averageScore: 95, level: 28, trend: 'stable', xp: 450, totalCoins: 2500 },
  { rank: 2, userId: '3', username: 'James Chen', avatarLetter: 'J', averageScore: 92, level: 26, trend: 'up', xp: 380, totalCoins: 2200 },
  { rank: 3, userId: '4', username: 'Maya Johnson', avatarLetter: 'M', averageScore: 90, level: 25, trend: 'up', xp: 300, totalCoins: 2000 },
  { rank: 4, userId: '5', username: 'Ryan Smith', avatarLetter: 'R', averageScore: 88, level: 24, trend: 'up', xp: 250, totalCoins: 1800 },
  { rank: 5, userId: '6', username: 'Diana Lee', avatarLetter: 'D', averageScore: 87, level: 23, trend: 'stable', xp: 200, totalCoins: 1600 },
  { rank: 6, userId: '7', username: 'Ahmad Khan', avatarLetter: 'A', averageScore: 85, level: 22, trend: 'down', xp: 150, totalCoins: 1400 },
  { rank: 7, userId: '8', username: 'Emma Wilson', avatarLetter: 'E', averageScore: 84, level: 21, trend: 'up', xp: 100, totalCoins: 1200 },
  { rank: 8, userId: '9', username: 'Lucas Brown', avatarLetter: 'L', averageScore: 83, level: 20, trend: 'stable', xp: 50, totalCoins: 1000 },
];

export const mockGoals: Goal[] = [
  {
    id: '1',
    userId: '1',
    subject: 'Mathematics',
    targetScore: 85,
    currentScore: 85,
    predictedScore: 90,
    minNeeded: 85,
    status: 'on-track',
  },
  {
    id: '2',
    userId: '1',
    subject: 'Physics',
    targetScore: 85,
    currentScore: 78,
    predictedScore: 80,
    minNeeded: 100,
    status: 'needs-effort',
  },
  {
    id: '3',
    userId: '1',
    subject: 'Chemistry',
    targetScore: 90,
    currentScore: 92,
    predictedScore: 95,
    minNeeded: 88,
    status: 'on-track',
  },
  {
    id: '4',
    userId: '1',
    subject: 'Biology',
    targetScore: 85,
    currentScore: 88,
    predictedScore: 90,
    minNeeded: 82,
    status: 'on-track',
  },
  {
    id: '5',
    userId: '1',
    subject: 'English',
    targetScore: 80,
    currentScore: 75,
    predictedScore: 78,
    minNeeded: 85,
    status: 'behind',
  },
  {
    id: '6',
    userId: '1',
    subject: 'IT',
    targetScore: 85,
    currentScore: 82,
    predictedScore: 84,
    minNeeded: 88,
    status: 'needs-effort',
  },
];

// Items (gems, crystals, etc.) with rarity tiers
export const mockCosmetics: Cosmetic[] = [
  { id: '1', name: 'Emerald', type: 'badge', rarity: 'rare', price: 150, owned: true, equipped: false },
  { id: '2', name: 'Ruby', type: 'badge', rarity: 'epic', price: 300, owned: true, equipped: false },
  { id: '3', name: 'Diamond', type: 'badge', rarity: 'legendary', price: 500, owned: false, equipped: false },
  { id: '4', name: 'Sapphire', type: 'badge', rarity: 'rare', price: 150, owned: true, equipped: true },
  { id: '5', name: 'Amethyst', type: 'badge', rarity: 'epic', price: 300, owned: false, equipped: false },
  { id: '6', name: 'Topaz', type: 'badge', rarity: 'common', price: 50, owned: true, equipped: false },
  { id: '7', name: 'Opal', type: 'badge', rarity: 'rare', price: 150, owned: false, equipped: false },
  { id: '8', name: 'Pearl', type: 'badge', rarity: 'common', price: 50, owned: true, equipped: false },
];

export const mockChallenges: GrimReaperChallenge[] = [
  {
    id: '1',
    creatorId: '3',
    creatorName: 'Alex Johnson',
    subject: 'Mathematics',
    stakedItem: mockCosmetics[0],
    estimatedValue: 150,
    targetScore: 90,
    deadline: '10 Dec 2025',
    participantCount: 5,
    status: 'open',
  },
  {
    id: '2',
    creatorId: '4',
    creatorName: 'Sarah Williams',
    subject: 'Physics',
    stakedCoins: 300,
    estimatedValue: 300,
    targetScore: 85,
    deadline: '15 Dec 2025',
    participantCount: 3,
    status: 'open',
  },
];

export const mockFriends: Friend[] = [
  { id: '2', username: 'Sarah Williams', handle: '@sarahw', avatarLetter: 'S', level: 28, status: 'online', grade: '12', class: 'A' },
  { id: '3', username: 'James Chen', handle: '@jameschen', avatarLetter: 'J', level: 26, status: 'online', grade: '12', class: 'B' },
  { id: '4', username: 'Maya Johnson', handle: '@mayaj', avatarLetter: 'M', level: 25, status: 'offline', grade: '12', class: 'A' },
  { id: '5', username: 'Ryan Smith', handle: '@ryansmith', avatarLetter: 'R', level: 24, status: 'offline', grade: '11', class: 'C' },
];

// Item values based on rarity
export const itemValues: Record<string, number> = {
  common: 50,
  uncommon: 100,
  rare: 150,
  epic: 300,
  legendary: 500,
  mythical: 1000,
};

// Calculate average score with proper significant figures rounding
export const calculateAverageScore = (grades: SubjectGrade[]): number => {
  const total = grades.reduce((sum, g) => sum + g.currentScore, 0);
  const avg = total / grades.length;
  // Use standard rounding (0.5 rounds up)
  return Math.round(avg);
};

// Calculate trend from history - using the last score vs first score of history
export const calculateTrend = (history: { month: string; score: number }[]): number => {
  if (history.length < 2) return 0;
  // Compare the latest month to the previous month
  return history[history.length - 1].score - history[history.length - 2].score;
};

// Simple linear regression for score prediction
export const predictNextScore = (history: { month: string; score: number }[]): number => {
  if (history.length < 2) return history[0]?.score || 0;
  
  const n = history.length;
  const xMean = (n - 1) / 2;
  const yMean = history.reduce((sum, h) => sum + h.score, 0) / n;
  
  let numerator = 0;
  let denominator = 0;
  
  history.forEach((h, i) => {
    numerator += (i - xMean) * (h.score - yMean);
    denominator += (i - xMean) ** 2;
  });
  
  const slope = denominator !== 0 ? numerator / denominator : 0;
  const intercept = yMean - slope * xMean;
  
  const predicted = Math.round(slope * n + intercept);
  return Math.min(100, Math.max(0, predicted));
};

// Coins calculation: 10 * max(next_score - max(target_score, predicted_score), 0)
export const calculateCoins = (nextScore: number, targetScore: number, predictedScore: number): number => {
  const threshold = Math.max(targetScore, predictedScore);
  const bonus = Math.max(nextScore - threshold, 0);
  return 10 * bonus;
};

// XP calculation: 25% of needed XP to level up
export const calculateXpReward = (currentXp: number, xpToNextLevel: number): number => {
  const neededXp = xpToNextLevel - currentXp;
  return Math.floor(neededXp * 0.25);
};

// Calculate XP required for each level (increasing XP per level)
export const getXpForLevel = (level: number): number => 100 * level;

// Roadmap milestones
export const roadmapMilestones = [
  { level: 10, rewards: { xp: 500, coins: 250, item: 'Topaz' } },
  { level: 20, rewards: { xp: 1000, coins: 500, item: 'Emerald' } },
  { level: 30, rewards: { xp: 1500, coins: 750, item: 'Ruby' } },
  { level: 40, rewards: { xp: 2000, coins: 1000, item: 'Sapphire' } },
  { level: 50, rewards: { xp: 3000, coins: 1500, item: 'Diamond' } },
];

// Podium rewards
export const podiumRewards = {
  1: { xp: 500, coins: 250 },
  2: { xp: 300, coins: 150 },
  3: { xp: 200, coins: 100 },
};