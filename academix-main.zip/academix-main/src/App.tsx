import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { TargetProvider } from "@/contexts/TargetContext";
import { CalendarProvider } from "@/contexts/CalendarContext";
import { MainLayout } from "@/components/layout/MainLayout";
import AuthPage from "./pages/AuthPage";
import Dashboard from "./pages/Dashboard";
import GradesPage from "./pages/GradesPage";
import TargetPage from "./pages/TargetPage";
import CalendarPage from "./pages/CalendarPage";
import FriendsPage from "./pages/FriendsPage";
import ChatPage from "./pages/ChatPage";
import LeaderboardPage from "./pages/LeaderboardPage";
import BarterPage from "./pages/BarterPage";
import ShopPage from "./pages/ShopPage";
import GrimReaperPage from "./pages/GrimReaperPage";
import NotesPage from "./pages/NotesPage";
import SettingsPage from "./pages/SettingsPage";
import InventoryPage from "./pages/InventoryPage";
import ProfilePage from "./pages/ProfilePage";
import NotFound from "./pages/NotFound";
import ActivityPage from "./pages/ActivityPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TargetProvider>
        <CalendarProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<Navigate to="/auth" replace />} />
                <Route path="/auth" element={<AuthPage />} />
                
                <Route element={<MainLayout />}>
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/grades" element={<GradesPage />} />
                  <Route path="/target" element={<TargetPage />} />
                  <Route path="/calendar" element={<CalendarPage />} />
                  <Route path="/notes" element={<NotesPage />} />
                  <Route path="/leaderboard" element={<LeaderboardPage />} />
                  <Route path="/friends" element={<FriendsPage />} />
                  <Route path="/chat" element={<ChatPage />} />
                  <Route path="/barter" element={<BarterPage />} />
                  <Route path="/grim-reaper" element={<GrimReaperPage />} />
                  <Route path="/shop" element={<ShopPage />} />
                  <Route path="/inventory" element={<InventoryPage />} />
                  <Route path="/settings" element={<SettingsPage />} />
                  <Route path="/profile/:userId?" element={<ProfilePage />} />
                  <Route path="/activity" element={<ActivityPage />} />
                </Route>
                
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </CalendarProvider>
      </TargetProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;