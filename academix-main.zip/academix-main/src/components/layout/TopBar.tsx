import { useState } from 'react';
import { Search, Bell, Zap, Coins, X, Trash2, Gem } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Link, useNavigate } from 'react-router-dom';
import { mockCosmetics } from '@/lib/mockData';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';

// Item values based on rarity
const itemValues: Record<string, number> = {
  common: 50,
  rare: 150,
  epic: 300,
  legendary: 500,
};

const initialNotifications = [
  { id: '1', title: 'Grade Updated', message: 'Your Math grade increased to 85!', time: '5 min ago', read: false },
  { id: '2', title: 'New Achievement', message: 'You unlocked "Study Streak" badge!', time: '1 hour ago', read: false },
  { id: '3', title: 'Friend Request', message: 'Sarah sent you a friend request', time: '2 hours ago', read: true },
];

// Search items
const searchItems = [
  { name: 'Dashboard', path: '/', category: 'Pages' },
  { name: 'Grades', path: '/grades', category: 'Pages' },
  { name: 'Leaderboard', path: '/leaderboard', category: 'Pages' },
  { name: 'Shop', path: '/shop', category: 'Pages' },
  { name: 'Inventory', path: '/inventory', category: 'Pages' },
  { name: 'Friends', path: '/friends', category: 'Pages' },
  { name: 'Grim Reaper', path: '/grim-reaper', category: 'Pages' },
  { name: 'Calendar', path: '/calendar', category: 'Pages' },
  { name: 'Notes', path: '/notes', category: 'Pages' },
  { name: 'Settings', path: '/settings', category: 'Pages' },
  { name: 'Profile', path: '/profile', category: 'Pages' },
  { name: 'Barter', path: '/barter', category: 'Pages' },
  { name: 'Chat', path: '/chat', category: 'Pages' },
  { name: 'Goals', path: '/target', category: 'Pages' },
  { name: 'Activity', path: '/activity', category: 'Pages' },
];

export const TopBar = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState(initialNotifications);
  const [notificationsCleared, setNotificationsCleared] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  if (!user) return null;

  const xpProgress = (user.xp / user.xpToNextLevel) * 100;
  const unreadCount = notificationsCleared ? 0 : notifications.filter(n => !n.read).length;
  
  // Calculate total item value
  const totalItemValue = mockCosmetics.filter(c => c.owned).reduce((sum, item) => sum + (itemValues[item.rarity] || 100), 0);

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const clearNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    setNotificationsCleared(true);
  };

  const handleSearch = (path: string) => {
    navigate(path);
    setSearchOpen(false);
    setSearchQuery('');
  };

  const filteredItems = searchQuery 
    ? searchItems.filter(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : searchItems;

  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-background/50 backdrop-blur-sm px-6">
      {/* Search - Made longer and functional */}
      <Popover open={searchOpen} onOpenChange={setSearchOpen}>
        <PopoverTrigger asChild>
          <div className="relative w-80">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search pages, features..."
              className="pl-10 bg-secondary/50 border-border focus:border-primary"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setSearchOpen(true);
              }}
              onFocus={() => setSearchOpen(true)}
            />
          </div>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-0" align="start">
          <Command>
            <CommandList>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup heading="Pages">
                {filteredItems.map(item => (
                  <CommandItem 
                    key={item.path}
                    onSelect={() => handleSearch(item.path)}
                    className="cursor-pointer"
                  >
                    {item.name}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

      {/* Right Section */}
      <div className="flex items-center gap-4">
        {/* Total Item Value */}
        <div className="flex items-center gap-2 rounded-full bg-purple-500/10 px-4 py-2">
          <Gem className="h-5 w-5 text-purple-400" />
          <span className="font-semibold text-purple-400">{totalItemValue.toLocaleString()}</span>
        </div>

        {/* Coins */}
        <div className="flex items-center gap-2 rounded-full bg-warning/10 px-4 py-2">
          <Coins className="h-5 w-5 text-warning" />
          <span className="font-semibold text-warning">{user.coins.toLocaleString()}</span>
        </div>

        {/* XP Bar */}
        <div className="flex items-center gap-2">
          <Zap className="h-4 w-4 text-primary" />
          <div className="w-24">
            <Progress value={xpProgress} className="h-2" />
          </div>
          <span className="text-xs text-muted-foreground">
            {user.xp} / {user.xpToNextLevel} XP
          </span>
        </div>

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground">
                  {unreadCount}
                </span>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <div className="flex items-center justify-between px-2">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              {notifications.length > 0 && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-7 text-xs text-destructive hover:text-destructive"
                  onClick={clearAllNotifications}
                >
                  <Trash2 className="h-3 w-3 mr-1" />
                  Clear All
                </Button>
              )}
            </div>
            <DropdownMenuSeparator />
            {notifications.length > 0 && !notificationsCleared ? (
              notifications.map((notification) => (
                <DropdownMenuItem
                  key={notification.id}
                  className={`flex items-start gap-3 p-3 cursor-pointer ${!notification.read ? 'bg-primary/5' : ''}`}
                  onClick={() => markAsRead(notification.id)}
                >
                  <div className="flex-1">
                    <p className={`text-sm font-medium ${!notification.read ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {notification.title}
                    </p>
                    <p className="text-xs text-muted-foreground">{notification.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">{notification.time}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={(e) => {
                      e.stopPropagation();
                      clearNotification(notification.id);
                    }}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </DropdownMenuItem>
              ))
            ) : (
              <div className="p-4 text-center text-sm text-muted-foreground">
                No notifications
              </div>
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Profile - Now clickable */}
        <Link to="/profile" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
          <Avatar className="h-9 w-9 avatar-ring">
            {user.avatarUrl ? (
              <AvatarImage src={user.avatarUrl} alt={user.username} />
            ) : null}
            <AvatarFallback className="bg-primary text-primary-foreground font-semibold">
              {user.avatarLetter}
            </AvatarFallback>
          </Avatar>
          <div className="hidden md:block">
            <p className="text-sm font-medium">{user.username}</p>
          </div>
          <div className="flex h-6 w-6 items-center justify-center rounded-full level-badge">
            <span className="text-xs font-bold text-primary-foreground">{user.level}</span>
          </div>
        </Link>
      </div>
    </header>
  );
};