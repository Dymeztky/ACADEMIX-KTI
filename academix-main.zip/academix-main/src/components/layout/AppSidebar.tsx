import { NavLink, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import {
  LayoutDashboard,
  BarChart3,
  Target,
  Calendar,
  Users,
  MessageCircle,
  Trophy,
  RefreshCw,
  ShoppingBag,
  Skull,
  Settings,
  LogOut,
  StickyNote,
  Package,
} from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

const mainMenuItems = [
  { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
  { name: 'Grades', path: '/grades', icon: BarChart3 },
  { name: 'Target', path: '/target', icon: Target },
  { name: 'Calendar', path: '/calendar', icon: Calendar },
  { name: 'Notes', path: '/notes', icon: StickyNote },
  { name: 'Leaderboard', path: '/leaderboard', icon: Trophy },
];

const socialMenuItems = [
  { name: 'Friends', path: '/friends', icon: Users },
  { name: 'Chat', path: '/chat', icon: MessageCircle },
  { name: 'Barter', path: '/barter', icon: RefreshCw },
  { name: 'Grim Reaper', path: '/grim-reaper', icon: Skull },
];

const collectionsMenuItems = [
  { name: 'Shop', path: '/shop', icon: ShoppingBag, badge: 3 },
  { name: 'Inventory', path: '/inventory', icon: Package },
];

export const AppSidebar = () => {
  const location = useLocation();
  const { logout } = useAuth();

  const isActive = (path: string) => location.pathname === path;

  const renderMenuSection = (items: Array<{ name: string; path: string; icon: React.ElementType; badge?: number }>, title?: string) => (
    <div className="space-y-1">
      {title && (
        <p className="px-3 py-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {title}
        </p>
      )}
      {items.map((item) => (
        <NavLink
          key={item.path}
          to={item.path}
          className={cn(
            'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200',
            isActive(item.path)
              ? 'bg-primary/10 text-primary border-l-2 border-primary'
              : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
          )}
        >
          <item.icon className="h-5 w-5" />
          <span>{item.name}</span>
          {'badge' in item && item.badge && (
            <span className="ml-auto flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
              {item.badge}
            </span>
          )}
        </NavLink>
      ))}
    </div>
  );

  return (
    <aside className="flex h-screen w-64 flex-col bg-sidebar sidebar-glow">
      {/* Logo */}
      <div className="flex items-center gap-2 p-6">
        <h1 className="font-display text-2xl font-bold text-gradient-glow">ACADEMIX</h1>
      </div>
      <p className="px-6 -mt-4 text-xs text-muted-foreground">Level Up Your Grades</p>

      {/* Navigation */}
      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="space-y-6">
          {renderMenuSection(mainMenuItems, 'Main Menu')}
          {renderMenuSection(socialMenuItems, 'Social')}
          {renderMenuSection(collectionsMenuItems, 'Collections')}
        </nav>
      </ScrollArea>

      {/* Footer Actions */}
      <div className="border-t border-border p-3 space-y-1">
        <NavLink
          to="/settings"
          className={cn(
            'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
            isActive('/settings')
              ? 'bg-primary/10 text-primary'
              : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
          )}
        >
          <Settings className="h-5 w-5" />
          <span>Settings</span>
        </NavLink>

        <button
          onClick={logout}
          className="flex w-full items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
        >
          <LogOut className="h-5 w-5" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
};