import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, UserPlus, Send } from 'lucide-react';
import { mockFriends } from '@/lib/mockData';
import { toast } from 'sonner';

interface InviteFriendsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  challengeId: string;
  challengeName: string;
}

const InviteFriendsDialog = ({ isOpen, onClose, challengeId, challengeName }: InviteFriendsDialogProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFriends, setSelectedFriends] = useState<string[]>([]);

  const filteredFriends = mockFriends.filter(f => 
    f.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.handle.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleFriend = (friendId: string) => {
    setSelectedFriends(prev => 
      prev.includes(friendId) 
        ? prev.filter(id => id !== friendId)
        : [...prev, friendId]
    );
  };

  const handleInvite = () => {
    if (selectedFriends.length === 0) {
      toast.error('Please select at least one friend to invite');
      return;
    }
    
    const invitedNames = mockFriends
      .filter(f => selectedFriends.includes(f.id))
      .map(f => f.username)
      .join(', ');
    
    toast.success(`Invitations sent to: ${invitedNames}`);
    setSelectedFriends([]);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5 text-destructive" />
            Invite Friends to Challenge
          </DialogTitle>
        </DialogHeader>
        
        <p className="text-sm text-muted-foreground">
          Invite friends to join "{challengeName}"
        </p>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search friends..."
            className="pl-10"
          />
        </div>
        
        <ScrollArea className="h-64">
          <div className="space-y-2">
            {filteredFriends.map((friend) => (
              <div
                key={friend.id}
                className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors ${
                  selectedFriends.includes(friend.id) 
                    ? 'bg-primary/10 border border-primary' 
                    : 'bg-secondary/30 hover:bg-secondary/50'
                }`}
                onClick={() => toggleFriend(friend.id)}
              >
                <Checkbox 
                  checked={selectedFriends.includes(friend.id)}
                  onCheckedChange={() => toggleFriend(friend.id)}
                />
                <Avatar className="h-10 w-10">
                  <AvatarFallback className={friend.status === 'online' ? 'bg-success/20 text-success' : ''}>
                    {friend.avatarLetter}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="font-medium text-sm">{friend.username}</p>
                  <p className="text-xs text-muted-foreground">{friend.handle}</p>
                </div>
                <div className={`w-2 h-2 rounded-full ${friend.status === 'online' ? 'bg-success' : 'bg-muted'}`} />
              </div>
            ))}
          </div>
        </ScrollArea>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button 
            onClick={handleInvite} 
            className="flex-1 gradient-destructive"
            disabled={selectedFriends.length === 0}
          >
            <Send className="h-4 w-4 mr-2" />
            Invite ({selectedFriends.length})
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default InviteFriendsDialog;
