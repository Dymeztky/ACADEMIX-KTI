import { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, Sparkles, X } from 'lucide-react';

interface DogMeshProps {
  isHappy: boolean;
}

const DogMesh = ({ isHappy }: DogMeshProps) => {
  const groupRef = useRef<THREE.Group>(null);
  const tailRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  
  useFrame((state) => {
    if (groupRef.current) {
      // Gentle floating animation
      groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.05;
      
      // Slight rotation when hovered
      if (hovered) {
        groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 3) * 0.1;
      }
    }
    
    // Tail wagging
    if (tailRef.current) {
      const wagSpeed = isHappy ? 15 : 8;
      const wagAmount = isHappy ? 0.5 : 0.3;
      tailRef.current.rotation.z = Math.sin(state.clock.elapsedTime * wagSpeed) * wagAmount;
    }
  });

  return (
    <group 
      ref={groupRef}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      {/* Body */}
      <RoundedBox args={[0.8, 0.5, 0.6]} radius={0.15} position={[0, 0, 0]}>
        <meshStandardMaterial color={hovered ? "#D4A574" : "#C4956A"} />
      </RoundedBox>
      
      {/* Head */}
      <RoundedBox args={[0.5, 0.45, 0.45]} radius={0.12} position={[0.5, 0.15, 0]}>
        <meshStandardMaterial color={hovered ? "#D4A574" : "#C4956A"} />
      </RoundedBox>
      
      {/* Snout */}
      <RoundedBox args={[0.2, 0.18, 0.2]} radius={0.05} position={[0.75, 0.05, 0]}>
        <meshStandardMaterial color="#E5C4A8" />
      </RoundedBox>
      
      {/* Nose */}
      <mesh position={[0.86, 0.08, 0]}>
        <sphereGeometry args={[0.05, 16, 16]} />
        <meshStandardMaterial color="#2C2C2C" />
      </mesh>
      
      {/* Eyes */}
      <mesh position={[0.65, 0.25, 0.15]}>
        <sphereGeometry args={[0.06, 16, 16]} />
        <meshStandardMaterial color="#2C2C2C" />
      </mesh>
      <mesh position={[0.65, 0.25, -0.15]}>
        <sphereGeometry args={[0.06, 16, 16]} />
        <meshStandardMaterial color="#2C2C2C" />
      </mesh>
      
      {/* Eye highlights */}
      <mesh position={[0.68, 0.27, 0.17]}>
        <sphereGeometry args={[0.02, 16, 16]} />
        <meshStandardMaterial color="#FFFFFF" />
      </mesh>
      <mesh position={[0.68, 0.27, -0.13]}>
        <sphereGeometry args={[0.02, 16, 16]} />
        <meshStandardMaterial color="#FFFFFF" />
      </mesh>
      
      {/* Ears */}
      <RoundedBox args={[0.15, 0.25, 0.08]} radius={0.03} position={[0.45, 0.4, 0.2]} rotation={[0, 0, 0.3]}>
        <meshStandardMaterial color="#A67C52" />
      </RoundedBox>
      <RoundedBox args={[0.15, 0.25, 0.08]} radius={0.03} position={[0.45, 0.4, -0.2]} rotation={[0, 0, -0.3]}>
        <meshStandardMaterial color="#A67C52" />
      </RoundedBox>
      
      {/* Legs */}
      <RoundedBox args={[0.12, 0.3, 0.12]} radius={0.04} position={[0.25, -0.35, 0.2]}>
        <meshStandardMaterial color="#C4956A" />
      </RoundedBox>
      <RoundedBox args={[0.12, 0.3, 0.12]} radius={0.04} position={[0.25, -0.35, -0.2]}>
        <meshStandardMaterial color="#C4956A" />
      </RoundedBox>
      <RoundedBox args={[0.12, 0.3, 0.12]} radius={0.04} position={[-0.25, -0.35, 0.2]}>
        <meshStandardMaterial color="#C4956A" />
      </RoundedBox>
      <RoundedBox args={[0.12, 0.3, 0.12]} radius={0.04} position={[-0.25, -0.35, -0.2]}>
        <meshStandardMaterial color="#C4956A" />
      </RoundedBox>
      
      {/* Tail */}
      <mesh ref={tailRef} position={[-0.5, 0.15, 0]} rotation={[0, 0, -0.5]}>
        <cylinderGeometry args={[0.05, 0.03, 0.25, 16]} />
        <meshStandardMaterial color="#A67C52" />
      </mesh>
    </group>
  );
};

interface Pet3DProps {
  position: { x: number; y: number };
  onInteract: () => void;
  isOpen: boolean;
  onClose: () => void;
  petName: string;
  petValue: number;
}

const Pet3D = ({ position, onInteract, isOpen, onClose, petName, petValue }: Pet3DProps) => {
  const [isHappy, setIsHappy] = useState(false);
  const [hearts, setHearts] = useState<number[]>([]);
  
  const handlePet = () => {
    setIsHappy(true);
    setHearts(prev => [...prev, Date.now()]);
    setTimeout(() => setIsHappy(false), 2000);
  };

  useEffect(() => {
    if (hearts.length > 0) {
      const timer = setTimeout(() => {
        setHearts(prev => prev.slice(1));
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [hearts]);

  if (!isOpen) {
    return (
      <div 
        className="fixed cursor-pointer z-40 transition-all duration-300 hover:scale-110"
        style={{ left: position.x, bottom: position.y }}
        onClick={onInteract}
      >
        <div className="relative">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-200 to-amber-400 shadow-lg flex items-center justify-center animate-bounce">
            <span className="text-2xl">🐕</span>
          </div>
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-success rounded-full animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm animate-fade-in">
      <Card className="w-[400px] bg-card border-border relative">
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 z-10"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
        <CardContent className="p-6">
          <div className="text-center mb-4">
            <h3 className="font-display text-xl font-bold">{petName}</h3>
            <p className="text-sm text-muted-foreground">Your loyal companion</p>
            <p className="text-xs text-success">Value: {petValue} coins</p>
          </div>
          
          <div className="h-64 rounded-lg overflow-hidden bg-gradient-to-b from-sky-200 to-green-200 relative">
            {/* Floating hearts */}
            {hearts.map((id) => (
              <div
                key={id}
                className="absolute animate-fade-in"
                style={{
                  left: `${30 + Math.random() * 40}%`,
                  top: `${20 + Math.random() * 30}%`,
                }}
              >
                <Heart className="h-6 w-6 text-pink-500 fill-pink-500 animate-bounce" />
              </div>
            ))}
            
            <Canvas camera={{ position: [3, 1.5, 3], fov: 45 }}>
              <ambientLight intensity={0.6} />
              <directionalLight position={[5, 5, 5]} intensity={1} />
              <pointLight position={[-5, 5, -5]} intensity={0.5} />
              <DogMesh isHappy={isHappy} />
              <OrbitControls 
                enablePan={false}
                enableZoom={false}
                minPolarAngle={Math.PI / 4}
                maxPolarAngle={Math.PI / 2}
              />
              
              {/* Ground */}
              <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.5, 0]}>
                <planeGeometry args={[10, 10]} />
                <meshStandardMaterial color="#7CB342" />
              </mesh>
            </Canvas>
          </div>
          
          <div className="flex gap-2 mt-4">
            <Button onClick={handlePet} className="flex-1 gradient-primary">
              <Heart className="h-4 w-4 mr-2" />
              Pet
            </Button>
            <Button variant="outline" className="flex-1">
              <Sparkles className="h-4 w-4 mr-2" />
              Feed
            </Button>
          </div>
          
          <div className="mt-4 p-3 rounded-lg bg-secondary/30 text-center">
            <p className="text-xs text-muted-foreground">
              {isHappy ? "Your pet is very happy! 💖" : "Click and drag to rotate. Pet to make them happy!"}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Pet3D;
