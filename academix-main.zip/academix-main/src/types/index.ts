export type UserRole = 'student' | 'teacher';

export type Grade = '10' | '11' | '12';
export type Class = 'A' | 'B' | 'C' | 'D';

export type Subject = 'Mathematics' | 'Physics' | 'Biology' | 'Chemistry' | 'English' | 'IT';

export interface User {
  id: string;
  username: string;
  handle: string;
  email: string;
  role: UserRole;
  grade?: Grade;
  class?: Class;
  level: number;
  xp: number;
  xpToNextLevel: number;
  coins: number;
  rank: number;
  streak: number;
  friendsCount: number;
  profileVisible: boolean;
  avatarUrl?: string;
  avatarLetter?: string;
  createdAt: string;
}

export interface GradeScore {
  id: string;
  userId: string;
  subject: Subject;
  score: number;
  date: string;
  month: string;
}

export interface SubjectGrade {
  subject: Subject;
  currentScore: number;
  previousScore: number;
  change: number;
  target: number;
  predictedScore: number;
  history: { month: string; score: number }[];
}

export interface Goal {
  id: string;
  userId: string;
  subject: Subject;
  targetScore: number;
  currentScore: number;
  predictedScore: number;
  minNeeded: number;
  status: 'on-track' | 'needs-effort' | 'behind';
}

export interface Activity {
  id: string;
  type: 'grade-increase' | 'achievement' | 'purchase' | 'target-achieved' | 'friend-added' | 'level-up';
  title: string;
  description: string;
  timestamp: string;
  reward?: { type: 'xp' | 'coins'; amount: number };
}

export interface CalendarEvent {
  id: string;
  title: string;
  subject?: Subject;
  type: 'exam' | 'quiz' | 'assignment' | 'event';
  date: string;
  time: string;
  daysLeft: number;
}

export interface Cosmetic {
  id: string;
  name: string;
  type: 'avatar' | 'background' | 'frame' | 'badge';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  price: number;
  imageUrl?: string;
  owned: boolean;
  equipped: boolean;
}

export interface BarterOffer {
  id: string;
  fromUserId: string;
  fromUsername: string;
  toUserId?: string;
  offeredItem: Cosmetic;
  requestedItem?: Cosmetic;
  requestedCoins?: number;
  status: 'open' | 'pending' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface GrimReaperChallenge {
  id: string;
  creatorId: string;
  creatorName: string;
  subject: Subject;
  stakedItem?: Cosmetic;
  stakedCoins?: number;
  estimatedValue: number;
  targetScore: number;
  deadline: string;
  participantCount: number;
  status: 'open' | 'in-progress' | 'completed';
}

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  username: string;
  avatarLetter: string;
  averageScore: number;
  level: number;
  trend: 'up' | 'down' | 'stable';
  xp?: number;
  totalCoins?: number;
}

export interface Friend {
  id: string;
  username: string;
  handle: string;
  avatarLetter: string;
  level: number;
  status: 'online' | 'offline';
  grade: Grade;
  class: Class;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: string;
  isPrivate: boolean;
  recipientId?: string;
}

export interface Note {
  id: string;
  userId: string;
  title: string;
  content: string;
  subject?: Subject;
  createdAt: string;
  updatedAt: string;
}
