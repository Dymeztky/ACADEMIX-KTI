import { useState } from 'react';
import { mockCosmetics, itemValues } from '@/lib/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { ShoppingBag, Coins, Sparkles, ArrowUpDown, RefreshCw, Gem, Search } from 'lucide-react';
import { toast } from 'sonner';

// Extended items collection with rarity tiers
const extendedItems = [
  ...mockCosmetics,
  { id: 'item1', name: 'Citrine', type: 'badge', rarity: 'uncommon', price: 100, owned: false, equipped: false },
  { id: 'item2', name: 'Aquamarine', type: 'badge', rarity: 'rare', price: 150, owned: false, equipped: false },
  { id: 'item3', name: 'Moonstone', type: 'badge', rarity: 'epic', price: 300, owned: false, equipped: false },
  { id: 'item4', name: 'Obsidian', type: 'badge', rarity: 'legendary', price: 500, owned: false, equipped: false },
  { id: 'item5', name: 'Alexandrite', type: 'badge', rarity: 'mythical', price: 1000, owned: false, equipped: false },
  { id: 'item6', name: 'Garnet', type: 'badge', rarity: 'common', price: 50, owned: false, equipped: false },
  { id: 'item7', name: 'Peridot', type: 'badge', rarity: 'uncommon', price: 100, owned: false, equipped: false },
  { id: 'item8', name: 'Tanzanite', type: 'badge', rarity: 'epic', price: 300, owned: false, equipped: false },
];

const ShopPage = () => {
  const { user, updateUser } = useAuth();
  const [items, setItems] = useState(extendedItems);
  const [activeTab, setActiveTab] = useState('all');
  const [sortOrder, setSortOrder] = useState<'low-high' | 'high-low'>('low-high');
  const [searchQuery, setSearchQuery] = useState('');
  const [tradeInDialog, setTradeInDialog] = useState<string | null>(null);
  const [selectedTradeItem, setSelectedTradeItem] = useState<string | null>(null);

  const rarityColors: Record<string, string> = {
    common: 'bg-gray-500/20 text-gray-400',
    uncommon: 'bg-green-500/20 text-green-400',
    rare: 'bg-primary/20 text-primary',
    epic: 'bg-purple-500/20 text-purple-400',
    legendary: 'bg-warning/20 text-warning',
    mythical: 'bg-pink-500/20 text-pink-400',
  };

  const handlePurchase = (itemId: string) => {
    const item = items.find(c => c.id === itemId);
    if (!item || !user) return;

    const price = itemValues[item.rarity] || item.price;
    if (user.coins < price) {
      toast.error('Not enough coins!');
      return;
    }

    updateUser({ coins: user.coins - price });
    setItems(prev => prev.map(c => 
      c.id === itemId ? { ...c, owned: true } : c
    ));
    toast.success(`Purchased ${item.name}!`);
  };

  const handleTradeIn = (itemId: string) => {
    const item = items.find(c => c.id === itemId);
    const tradeItem = items.find(c => c.id === selectedTradeItem);
    if (!item || !tradeItem || !user) return;

    const tradeValue = Math.floor((itemValues[tradeItem.rarity] || 100) * 0.5);
    const price = itemValues[item.rarity] || item.price;
    const remaining = price - tradeValue;

    if (remaining > user.coins) {
      toast.error('Not enough coins for trade-in!');
      return;
    }

    updateUser({ coins: user.coins - remaining });
    setItems(prev => prev.map(c => {
      if (c.id === itemId) return { ...c, owned: true };
      if (c.id === selectedTradeItem) return { ...c, owned: false };
      return c;
    }));

    setTradeInDialog(null);
    setSelectedTradeItem(null);
    toast.success(`Trade-in successful! Got ${item.name}!`);
  };

  const getOwnedDuplicates = () => {
    return items.filter(c => c.owned && !c.equipped);
  };

  const getFilteredItems = () => {
    let filtered = items.filter(c => !c.owned);
    
    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(c => 
        c.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    // Rarity filter
    if (activeTab !== 'all') {
      filtered = filtered.filter(c => c.rarity === activeTab);
    }

    // Sort
    filtered.sort((a, b) => {
      const priceA = itemValues[a.rarity] || a.price;
      const priceB = itemValues[b.rarity] || b.price;
      return sortOrder === 'low-high' ? priceA - priceB : priceB - priceA;
    });

    return filtered;
  };

  const availableItems = getFilteredItems();
  const duplicates = getOwnedDuplicates();

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <ShoppingBag className="h-8 w-8 text-warning" />
          <div>
            <h1 className="font-display text-3xl font-bold">Shop</h1>
            <p className="text-muted-foreground">Buy items with your coins</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-warning/10">
          <Coins className="h-5 w-5 text-warning" />
          <span className="font-semibold text-warning">{user?.coins.toLocaleString()}</span>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search items by name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Filter Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <TabsList className="bg-secondary/50 flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="all" className="flex items-center gap-1">
              <Sparkles className="h-4 w-4" />
              All
            </TabsTrigger>
            <TabsTrigger value="common">Common</TabsTrigger>
            <TabsTrigger value="uncommon">Uncommon</TabsTrigger>
            <TabsTrigger value="rare">Rare</TabsTrigger>
            <TabsTrigger value="epic">Epic</TabsTrigger>
            <TabsTrigger value="legendary">Legendary</TabsTrigger>
            <TabsTrigger value="mythical">Mythical</TabsTrigger>
          </TabsList>

          <Select value={sortOrder} onValueChange={(v) => setSortOrder(v as 'low-high' | 'high-low')}>
            <SelectTrigger className="w-48">
              <ArrowUpDown className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Sort by price" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low-high">Price: Low to High</SelectItem>
              <SelectItem value="high-low">Price: High to Low</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <TabsContent value={activeTab} className="mt-6">
          {availableItems.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {availableItems.map((item) => {
                const price = itemValues[item.rarity] || item.price;
                return (
                  <Card key={item.id} className="bg-card border-border hover:border-primary/50 transition-colors">
                    <CardContent className="p-4 flex flex-col">
                      <div className={`aspect-square rounded-lg mb-4 flex items-center justify-center ${rarityColors[item.rarity]}`}>
                        <Gem className="h-8 w-8" />
                      </div>
                      
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold text-sm">{item.name}</h3>
                          <Badge className={rarityColors[item.rarity]}>
                            {item.rarity}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-muted-foreground capitalize">Item</p>
                          <p className="text-xs text-primary flex items-center gap-1">
                            <Gem className="h-3 w-3" />
                            {price}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 mt-3">
                        <Button 
                          onClick={() => handlePurchase(item.id)}
                          className="flex-1 gradient-warning text-warning-foreground"
                          disabled={!user || user.coins < price}
                        >
                          <Coins className="h-4 w-4 mr-1" />
                          {price}
                        </Button>
                        {duplicates.length > 0 && (
                          <Button 
                            variant="outline"
                            size="icon"
                            onClick={() => setTradeInDialog(item.id)}
                            title="Trade-in with duplicates"
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card className="bg-card border-border">
              <CardContent className="p-8 text-center">
                <ShoppingBag className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">No items available</h3>
                <p className="text-muted-foreground">Check other categories or you own all items!</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Trade-in Dialog */}
      <Dialog open={!!tradeInDialog} onOpenChange={() => { setTradeInDialog(null); setSelectedTradeItem(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Trade-In Item</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Select a duplicate item to trade in. You'll get 50% of its value towards your purchase.
            </p>

            {duplicates.length > 0 ? (
              <div className="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto">
                {duplicates.map(item => {
                  const tradeValue = Math.floor((itemValues[item.rarity] || 100) * 0.5);
                  return (
                    <button
                      key={item.id}
                      onClick={() => setSelectedTradeItem(item.id)}
                      className={`p-3 rounded-lg border text-left transition-colors ${
                        selectedTradeItem === item.id ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <p className="font-medium text-sm">{item.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{item.rarity}</p>
                      <p className="text-xs text-success">+{tradeValue} coins value</p>
                    </button>
                  );
                })}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-4">No duplicate items available</p>
            )}

            {selectedTradeItem && tradeInDialog && (
              <div className="p-4 rounded-lg bg-secondary/30">
                <p className="text-sm">
                  Trade value: <span className="text-success font-semibold">
                    {Math.floor((itemValues[duplicates.find(d => d.id === selectedTradeItem)?.rarity || 'common'] || 100) * 0.5)} coins
                  </span>
                </p>
                <p className="text-sm">
                  Remaining: <span className="text-warning font-semibold">
                    {(itemValues[items.find(c => c.id === tradeInDialog)?.rarity || 'common'] || 0) - Math.floor((itemValues[duplicates.find(d => d.id === selectedTradeItem)?.rarity || 'common'] || 100) * 0.5)} coins
                  </span>
                </p>
              </div>
            )}

            <Button 
              onClick={() => handleTradeIn(tradeInDialog!)}
              className="w-full gradient-primary"
              disabled={!selectedTradeItem}
            >
              Complete Trade-In
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ShopPage;