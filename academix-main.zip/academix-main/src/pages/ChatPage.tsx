import { useState, useRef, useEffect } from 'react';
import { mockFriends } from '@/lib/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { MessageCircle, Send, Users, Hash, Plus, UserPlus } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'sonner';

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: string;
  avatarLetter: string;
}

interface ChatMessages {
  [chatId: string]: Message[];
}

interface GroupChat {
  id: string;
  name: string;
  members: string[];
  memberNames: string[];
}

const ChatPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [selectedChat, setSelectedChat] = useState<string>('global');
  const [messageInput, setMessageInput] = useState('');
  const [isCreateGroupOpen, setIsCreateGroupOpen] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  
  const [groupChats, setGroupChats] = useState<GroupChat[]>([]);
  
  // Separate messages for each chat
  const [chatMessages, setChatMessages] = useState<ChatMessages>({
    global: [
      { id: '1', senderId: '2', senderName: 'Sarah Williams', content: 'Hey everyone! How did the math test go?', timestamp: '10:30 AM', avatarLetter: 'S' },
      { id: '2', senderId: '3', senderName: 'James Chen', content: 'It was tough! Question 5 was really hard.', timestamp: '10:32 AM', avatarLetter: 'J' },
      { id: '3', senderId: '4', senderName: 'Maya Johnson', content: "I think I did okay, but we'll see!", timestamp: '10:35 AM', avatarLetter: 'M' },
    ],
    '2': [
      { id: '1', senderId: '2', senderName: 'Sarah Williams', content: 'Hey! Did you finish the homework?', timestamp: '9:00 AM', avatarLetter: 'S' },
    ],
    '3': [
      { id: '1', senderId: '3', senderName: 'James Chen', content: 'Want to study together for the quiz?', timestamp: '8:30 AM', avatarLetter: 'J' },
    ],
    '4': [
      { id: '1', senderId: '4', senderName: 'Maya Johnson', content: 'Thanks for the notes yesterday!', timestamp: '7:45 AM', avatarLetter: 'M' },
    ],
    '5': [],
  });
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const currentMessages = chatMessages[selectedChat] || [];

  useEffect(() => {
    scrollToBottom();
  }, [currentMessages]);

  const handleSendMessage = () => {
    if (!messageInput.trim() || !user) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      senderId: user.id,
      senderName: user.username,
      content: messageInput,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      avatarLetter: user.avatarLetter || 'U',
    };

    setChatMessages(prev => ({
      ...prev,
      [selectedChat]: [...(prev[selectedChat] || []), newMessage],
    }));
    setMessageInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleCreateGroup = () => {
    if (!groupName.trim()) {
      toast.error('Please enter a group name');
      return;
    }
    if (selectedMembers.length === 0) {
      toast.error('Please select at least one member');
      return;
    }

    const memberNames = selectedMembers.map(id => 
      mockFriends.find(f => f.id === id)?.username || ''
    ).filter(Boolean);

    const newGroup: GroupChat = {
      id: `group-${Date.now()}`,
      name: groupName,
      members: selectedMembers,
      memberNames,
    };

    setGroupChats(prev => [...prev, newGroup]);
    setChatMessages(prev => ({
      ...prev,
      [newGroup.id]: [],
    }));

    setGroupName('');
    setSelectedMembers([]);
    setIsCreateGroupOpen(false);
    toast.success(`Group "${groupName}" created!`);
  };

  const toggleMember = (memberId: string) => {
    setSelectedMembers(prev => 
      prev.includes(memberId)
        ? prev.filter(id => id !== memberId)
        : [...prev, memberId]
    );
  };

  const getChatName = () => {
    if (selectedChat === 'global') return 'Global Chat';
    if (selectedChat.startsWith('group-')) {
      return groupChats.find(g => g.id === selectedChat)?.name || 'Group';
    }
    return mockFriends.find(f => f.id === selectedChat)?.username || 'Chat';
  };

  const handleViewProfile = (userId: string) => {
    navigate(`/profile/${userId}`);
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-4 animate-fade-in">
      {/* Sidebar */}
      <Card className="w-64 bg-card border-border flex-shrink-0 flex flex-col overflow-hidden">
        <CardHeader className="pb-2 flex-shrink-0">
          <div className="flex items-center justify-between">
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Chats
            </CardTitle>
            <Dialog open={isCreateGroupOpen} onOpenChange={setIsCreateGroupOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Plus className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Group Chat</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Group Name</Label>
                    <Input
                      value={groupName}
                      onChange={(e) => setGroupName(e.target.value)}
                      placeholder="Enter group name..."
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Select Members</Label>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {mockFriends.map(friend => (
                        <div 
                          key={friend.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/50 cursor-pointer"
                          onClick={() => toggleMember(friend.id)}
                        >
                          <Checkbox
                            checked={selectedMembers.includes(friend.id)}
                            onCheckedChange={() => toggleMember(friend.id)}
                          />
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                              {friend.avatarLetter}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-sm">{friend.username}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <Button onClick={handleCreateGroup} className="w-full gradient-primary">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Create Group
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="p-2 flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            {/* Global Chat */}
            <button
              onClick={() => setSelectedChat('global')}
              className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                selectedChat === 'global' ? 'bg-primary/10 text-primary' : 'hover:bg-secondary/50'
              }`}
            >
              <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Hash className="h-5 w-5 text-primary" />
              </div>
              <div className="text-left min-w-0">
                <p className="font-medium text-sm truncate">Global Chat</p>
                <p className="text-xs text-muted-foreground truncate">All students</p>
              </div>
            </button>

            {/* Group Chats */}
            {groupChats.length > 0 && (
              <>
                <div className="my-2 border-t border-border" />
                <p className="px-3 py-2 text-xs font-medium text-muted-foreground uppercase">Groups</p>
                {groupChats.map(group => (
                  <button
                    key={group.id}
                    onClick={() => setSelectedChat(group.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                      selectedChat === group.id ? 'bg-primary/10 text-primary' : 'hover:bg-secondary/50'
                    }`}
                  >
                    <div className="h-10 w-10 rounded-lg bg-success/20 flex items-center justify-center flex-shrink-0">
                      <Users className="h-5 w-5 text-success" />
                    </div>
                    <div className="text-left min-w-0">
                      <p className="font-medium text-sm truncate">{group.name}</p>
                      <p className="text-xs text-muted-foreground truncate">{group.memberNames.length} members</p>
                    </div>
                  </button>
                ))}
              </>
            )}

            <div className="my-2 border-t border-border" />
            
            {/* Direct Messages */}
            <p className="px-3 py-2 text-xs font-medium text-muted-foreground uppercase">Direct Messages</p>
            {mockFriends.map(friend => (
              <button
                key={friend.id}
                onClick={() => setSelectedChat(friend.id)}
                className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                  selectedChat === friend.id ? 'bg-primary/10 text-primary' : 'hover:bg-secondary/50'
                }`}
              >
                <div className="relative flex-shrink-0">
                  <button onClick={(e) => { e.stopPropagation(); handleViewProfile(friend.id); }}>
                    <Avatar className="h-10 w-10 hover:opacity-80 transition-opacity">
                      <AvatarFallback className="bg-secondary">
                        {friend.avatarLetter}
                      </AvatarFallback>
                    </Avatar>
                  </button>
                  <div className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-card ${
                    friend.status === 'online' ? 'bg-success' : 'bg-muted'
                  }`} />
                </div>
                <div className="text-left flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{friend.username}</p>
                  <p className="text-xs text-muted-foreground truncate">{friend.status}</p>
                </div>
              </button>
            ))}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Chat Area */}
      <Card className="flex-1 bg-card border-border flex flex-col overflow-hidden">
        <CardHeader className="border-b border-border pb-4 flex-shrink-0">
          <CardTitle className="font-display text-lg flex items-center gap-2">
            {selectedChat === 'global' ? (
              <>
                <Hash className="h-5 w-5 text-primary" />
                Global Chat
              </>
            ) : selectedChat.startsWith('group-') ? (
              <>
                <Users className="h-5 w-5 text-success" />
                {getChatName()}
              </>
            ) : (
              <>
                <button onClick={() => handleViewProfile(selectedChat)} className="hover:opacity-80 transition-opacity">
                  <Users className="h-5 w-5 text-primary" />
                </button>
                <button 
                  onClick={() => handleViewProfile(selectedChat)}
                  className="hover:text-primary transition-colors"
                >
                  {getChatName()}
                </button>
              </>
            )}
          </CardTitle>
        </CardHeader>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {currentMessages.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No messages yet. Start the conversation!</p>
              </div>
            ) : (
              currentMessages.map(message => (
                <div 
                  key={message.id}
                  className={`flex gap-3 ${message.senderId === user?.id ? 'flex-row-reverse' : ''}`}
                >
                  <button 
                    onClick={() => message.senderId !== user?.id && handleViewProfile(message.senderId)}
                    className={message.senderId !== user?.id ? 'hover:opacity-80 transition-opacity' : ''}
                  >
                    <Avatar className="h-8 w-8 flex-shrink-0">
                      <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                        {message.avatarLetter}
                      </AvatarFallback>
                    </Avatar>
                  </button>
                  <div className={`max-w-[70%] ${message.senderId === user?.id ? 'text-right' : ''}`}>
                    <div className={`flex items-center gap-2 mb-1 ${message.senderId === user?.id ? 'flex-row-reverse' : ''}`}>
                      <span className="text-sm font-medium">{message.senderName}</span>
                      <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                    </div>
                    <div className={`inline-block p-3 rounded-lg ${
                      message.senderId === user?.id 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-secondary'
                    }`}>
                      <p className="text-sm">{message.content}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="p-4 border-t border-border flex-shrink-0">
          <div className="flex gap-2">
            <Input
              placeholder="Type a message..."
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyDown={handleKeyPress}
              className="flex-1"
            />
            <Button onClick={handleSendMessage} className="gradient-primary">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ChatPage;