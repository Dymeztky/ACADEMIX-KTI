import { useState } from 'react';
import { mockSubjectGrades, calculateTrend, calculateAverageScore } from '@/lib/mockData';
import { useTargets } from '@/contexts/TargetContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, TrendingUp, TrendingDown, Target, BookOpen, ArrowRight } from 'lucide-react';
import { 
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine
} from 'recharts';
import type { Subject } from '@/types';

const subjectAbbr: Record<string, string> = {
  'Mathematics': 'MATH',
  'Physics': 'PHY',
  'Chemistry': 'CHEM',
  'Biology': 'BIO',
  'English': 'ENG',
  'IT': 'IT',
};

// Only Jan to May
const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May'];

const GradesPage = () => {
  const { getTarget } = useTargets();
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [activeChartSubject, setActiveChartSubject] = useState('Mathematics');
  const [viewMode, setViewMode] = useState<'monthly' | 'weekly'>('monthly');
  const [selectedMonth, setSelectedMonth] = useState('May');
  
  // Use proper rounding with significant figures
  const averageScore = calculateAverageScore(mockSubjectGrades);

  const highestGrade = Math.max(...mockSubjectGrades.map(g => g.currentScore));
  const lowestGrade = Math.min(...mockSubjectGrades.map(g => g.currentScore));

  const radarData = mockSubjectGrades.map(g => ({
    subject: subjectAbbr[g.subject],
    fullName: g.subject,
    score: g.currentScore,
    fullMark: 100,
  }));

  const selectedGrade = mockSubjectGrades.find(g => g.subject === selectedSubject);
  const activeGradeData = mockSubjectGrades.find(g => g.subject === activeChartSubject);
  const currentTarget = getTarget(activeChartSubject as Subject);
  
  // Get trend based on actual score history
  const getActualTrend = (history: { month: string; score: number }[]) => {
    return calculateTrend(history);
  };

  // Filter history to only show Jan-May
  const getFilteredHistory = (history: { month: string; score: number }[]) => {
    return history.filter(h => months.includes(h.month));
  };

  // Generate weekly data for a specific month (W1-W4) based on actual history
  const getWeeklyDataForMonth = (history: { month: string; score: number }[], month: string) => {
    const monthData = history.find(h => h.month === month);
    if (!monthData) return [];
    
    const baseScore = monthData.score;
    // Generate slight variations around the base score
    return [
      { week: 'W1', score: Math.min(100, Math.max(0, baseScore - 2)), target: currentTarget },
      { week: 'W2', score: Math.min(100, Math.max(0, baseScore - 1)), target: currentTarget },
      { week: 'W3', score: Math.min(100, Math.max(0, baseScore)), target: currentTarget },
      { week: 'W4', score: Math.min(100, Math.max(0, baseScore + 1)), target: currentTarget },
    ];
  };

  // Custom tooltip for radar chart
  const CustomRadarTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="font-semibold text-foreground">{payload[0].payload.fullName}</p>
          <p className="text-primary font-bold text-lg">{payload[0].value}</p>
        </div>
      );
    }
    return null;
  };

  // Add target to monthly data for chart
  const getMonthlyDataWithTarget = (history: { month: string; score: number }[]) => {
    return getFilteredHistory(history).map(h => ({
      ...h,
      target: currentTarget,
    }));
  };

  if (selectedSubject && selectedGrade) {
    const filteredHistory = getFilteredHistory(selectedGrade.history);
    const weeklyHistory = getWeeklyDataForMonth(selectedGrade.history, selectedMonth);
    const trend = getActualTrend(selectedGrade.history);

    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <Button 
            variant="ghost" 
            onClick={() => setSelectedSubject(null)}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="font-display text-3xl font-bold">{selectedSubject}</h1>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <p className="text-sm text-muted-foreground mb-2">Current Grade</p>
              <p className="font-display text-4xl font-bold text-primary">{selectedGrade.currentScore}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <p className="text-sm text-muted-foreground mb-2">Target</p>
              <p className="font-display text-4xl font-bold">{getTarget(selectedSubject as Subject)}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <p className="text-sm text-muted-foreground mb-2">Trend</p>
              <p className={`font-display text-4xl font-bold ${
                trend > 0 ? 'text-success' : trend < 0 ? 'text-destructive' : ''
              }`}>
                {trend > 0 ? `+${trend}` : trend}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Progress Chart with View Mode Toggle */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="font-display">Grade Progress</CardTitle>
            <div className="flex gap-2">
              <Button
                variant={viewMode === 'monthly' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('monthly')}
                className={viewMode === 'monthly' ? 'gradient-primary' : ''}
              >
                Monthly
              </Button>
              <Button
                variant={viewMode === 'weekly' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('weekly')}
                className={viewMode === 'weekly' ? 'gradient-primary' : ''}
              >
                Weekly
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {viewMode === 'monthly' ? (
              <div className="space-y-4">
                {filteredHistory.map((h) => (
                  <div key={h.month} className="flex items-center gap-4">
                    <span className="w-12 text-sm text-muted-foreground">{h.month}</span>
                    <div className="flex-1">
                      <div className="relative h-8 rounded-lg bg-secondary overflow-hidden">
                        <div 
                          className="absolute inset-y-0 left-0 xp-bar rounded-lg transition-all duration-500"
                          style={{ width: `${h.score}%` }}
                        />
                        {getTarget(selectedSubject as Subject) && (
                          <div 
                            className="absolute inset-y-0 w-0.5 bg-warning transition-all duration-500"
                            style={{ left: `${getTarget(selectedSubject as Subject)}%` }}
                          />
                        )}
                      </div>
                    </div>
                    <span className="w-12 text-right font-semibold">{h.score}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {/* Month selector for weekly view */}
                <div className="flex gap-2 flex-wrap">
                  {months.map(m => (
                    <Button
                      key={m}
                      variant={selectedMonth === m ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedMonth(m)}
                      className={selectedMonth === m ? 'gradient-primary' : ''}
                    >
                      {m}
                    </Button>
                  ))}
                </div>
                <p className="text-sm text-muted-foreground">{selectedMonth} Weekly Scores:</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {weeklyHistory.map((w) => (
                    <div key={w.week} className="p-4 rounded-lg bg-secondary/30 text-center">
                      <p className="text-sm text-muted-foreground mb-1">{selectedMonth} {w.week}</p>
                      <p className={`font-display text-2xl font-bold ${
                        w.score >= (getTarget(selectedSubject as Subject) || 0) ? 'text-success' : 'text-foreground'
                      }`}>{w.score}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-3xl font-bold">Grade Overview</h1>
        <p className="text-muted-foreground">View your academic performance</p>
      </div>

      {/* Stats Cards Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/20">
              <Target className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Average</p>
              <p className="font-display text-2xl font-bold">{averageScore}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-success/20">
              <TrendingUp className="h-5 w-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Highest Grade</p>
              <p className="font-display text-2xl font-bold">{highestGrade}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-destructive/20">
              <TrendingDown className="h-5 w-5 text-destructive" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Lowest Grade</p>
              <p className="font-display text-2xl font-bold">{lowestGrade}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-warning/20">
              <BookOpen className="h-5 w-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Subjects</p>
              <p className="font-display text-2xl font-bold">{mockSubjectGrades.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Radar Chart with Subject List */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="font-display">Grade Chart</CardTitle>
              <p className="text-sm text-muted-foreground">Hover to see scores</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Average</p>
              <p className="font-display text-4xl font-bold text-primary">{averageScore}</p>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-6">
              <div className="w-64 h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="hsl(var(--border))" />
                    <PolarAngleAxis 
                      dataKey="subject" 
                      tick={{ 
                        fill: 'hsl(var(--muted-foreground))', 
                        fontSize: 12,
                      }} 
                    />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }} />
                    <Radar
                      name="Score"
                      dataKey="score"
                      stroke="hsl(var(--primary))"
                      fill="hsl(var(--primary))"
                      fillOpacity={0.3}
                      strokeWidth={2}
                    />
                    <Tooltip content={<CustomRadarTooltip />} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              
              <div className="flex-1 space-y-3">
                {mockSubjectGrades.map(g => {
                  const trend = getActualTrend(g.history);
                  return (
                    <div key={g.subject} className="flex items-center justify-between py-1">
                      <span className="text-sm">{g.subject}</span>
                      <div className="flex items-center gap-3">
                        <span className="font-semibold w-8 text-right">{g.currentScore}</span>
                        <span className={`text-xs font-medium w-8 ${
                          trend > 0 ? 'text-success' : trend < 0 ? 'text-destructive' : 'text-muted-foreground'
                        }`}>
                          {trend > 0 ? `+${trend}` : trend}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Line Chart with View Mode and Target Line */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="font-display">Grade Progress</CardTitle>
                <p className="text-sm text-muted-foreground">Per subject</p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant={viewMode === 'monthly' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('monthly')}
                  className={viewMode === 'monthly' ? 'gradient-primary' : ''}
                >
                  Monthly
                </Button>
                <Button
                  variant={viewMode === 'weekly' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('weekly')}
                  className={viewMode === 'weekly' ? 'gradient-primary' : ''}
                >
                  Weekly
                </Button>
              </div>
            </div>
            <div className="flex gap-2 flex-wrap mt-2">
              {mockSubjectGrades.map(g => (
                <Button
                  key={g.subject}
                  variant={activeChartSubject === g.subject ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveChartSubject(g.subject)}
                  className={activeChartSubject === g.subject ? 'gradient-primary' : ''}
                >
                  {g.subject}
                </Button>
              ))}
            </div>
            {viewMode === 'weekly' && (
              <div className="flex gap-2 flex-wrap mt-2">
                {months.map(m => (
                  <Button
                    key={m}
                    variant={selectedMonth === m ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedMonth(m)}
                    className={selectedMonth === m ? 'gradient-secondary' : ''}
                  >
                    {m}
                  </Button>
                ))}
              </div>
            )}
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={viewMode === 'monthly' 
                  ? getMonthlyDataWithTarget(activeGradeData?.history || [])
                  : getWeeklyDataForMonth(activeGradeData?.history || [], selectedMonth)
                }>
                  <defs>
                    <linearGradient id="colorScoreGrades" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey={viewMode === 'monthly' ? 'month' : 'week'} 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                  />
                  <YAxis domain={[60, 100]} stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }} 
                  />
                  {/* Target Reference Line - synced with context */}
                  <ReferenceLine 
                    y={currentTarget} 
                    stroke="hsl(var(--warning))" 
                    strokeDasharray="5 5" 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="score" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    fill="url(#colorScoreGrades)"
                    dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            {/* Legend */}
            <div className="flex items-center justify-center gap-6 mt-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-primary" />
                <span className="text-sm text-muted-foreground">Your Score</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-warning" />
                <span className="text-sm text-muted-foreground">Target ({currentTarget})</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Subject Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockSubjectGrades.map(g => {
          const trend = getActualTrend(g.history);
          const target = getTarget(g.subject as Subject);
          return (
            <Card 
              key={g.subject} 
              className="bg-card border-border hover:border-primary/50 transition-colors cursor-pointer"
              onClick={() => setSelectedSubject(g.subject)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold">{g.subject}</h3>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-medium ${
                      trend > 0 ? 'text-success' : trend < 0 ? 'text-destructive' : 'text-muted-foreground'
                    }`}>
                      {trend > 0 ? `+${trend}` : trend}
                    </span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
                <div className="flex items-end justify-between">
                  <p className="font-display text-3xl font-bold text-primary">{g.currentScore}</p>
                  <p className="text-sm text-muted-foreground">Target: {target}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default GradesPage;