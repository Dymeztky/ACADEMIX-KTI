import { useAuth } from '@/contexts/AuthContext';
import { mockSubjectGrades, mockActivities, mockLeaderboard, calculateAverageScore } from '@/lib/mockData';
import { useCalendar } from '@/contexts/CalendarContext';
import { useTargets } from '@/contexts/TargetContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  ResponsiveContainer, Area, AreaChart, CartesianGrid, XAxis, YAxis, Tooltip, ReferenceLine
} from 'recharts';
import { 
  Trophy, Star, TrendingUp, ShoppingBag, Users, 
  StickyNote, Target, Skull, Calendar, Zap, Coins,
  ArrowRight
} from 'lucide-react';
import { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import type { Subject } from '@/types';

const subjectAbbr: Record<string, string> = {
  'Mathematics': 'MATH',
  'Physics': 'PHY',
  'Chemistry': 'CHEM',
  'Biology': 'BIO',
  'English': 'ENG',
  'IT': 'IT',
};

const Dashboard = () => {
  const { user } = useAuth();
  const { events: calendarEvents } = useCalendar();
  const { getTarget } = useTargets();
  const navigate = useNavigate();
  const [selectedSubject, setSelectedSubject] = useState<Subject>('Mathematics');
  
  if (!user) return null;

  // Correct average calculation
  const averageScore = calculateAverageScore(mockSubjectGrades);
  const xpProgress = (user.xp / user.xpToNextLevel) * 100;

  const radarData = mockSubjectGrades.map(g => ({
    subject: subjectAbbr[g.subject],
    fullName: g.subject,
    score: g.currentScore,
    fullMark: 100,
  }));

  const selectedGrade = mockSubjectGrades.find(g => g.subject === selectedSubject);
  const currentTarget = getTarget(selectedSubject);

  // Get user's actual rank from leaderboard
  const userRank = mockLeaderboard.findIndex(e => e.userId === user.id) + 1 || user.rank;

  // Get upcoming events from calendar, sorted by date
  const upcomingEvents = useMemo(() => {
    return [...calendarEvents]
      .filter(e => new Date(e.date) >= new Date())
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 5);
  }, [calendarEvents]);

  // Rearranged Quick Actions: Goals → Notes → Leaderboard → Friends → Grim Reaper → Shop
  const quickActions = [
    { name: 'Goals', description: 'Set your grade targets', icon: Target, gradient: 'from-yellow-500/20 to-yellow-600/5', iconBg: 'bg-yellow-500/20', iconColor: 'text-yellow-500', titleColor: 'text-yellow-500', link: '/target' },
    { name: 'Notes', description: 'Upload & access your notes', icon: StickyNote, gradient: 'from-primary/20 to-primary/5', iconBg: 'bg-primary/20', iconColor: 'text-primary', titleColor: 'text-foreground', link: '/notes' },
    { name: 'Leaderboard', description: 'View your class rankings', icon: Trophy, gradient: 'from-primary/20 to-primary/5', iconBg: 'bg-primary/20', iconColor: 'text-primary', titleColor: 'text-primary', link: '/leaderboard' },
    { name: 'Friends', description: "See your friends' progress", icon: Users, gradient: 'from-green-500/20 to-green-600/5', iconBg: 'bg-green-500/20', iconColor: 'text-green-500', titleColor: 'text-green-500', link: '/friends' },
    { name: 'Grim Reaper', description: 'Bet on grades, win items!', icon: Skull, gradient: 'from-destructive/20 to-destructive/5', iconBg: 'bg-destructive/20', iconColor: 'text-destructive', titleColor: 'text-foreground', badge: '2 Live', badgeColor: 'bg-success/20 text-success', link: '/grim-reaper' },
    { name: 'Shop', description: 'Buy items & collections', icon: ShoppingBag, gradient: 'from-yellow-500/20 to-yellow-600/5', iconBg: 'bg-yellow-500/20', iconColor: 'text-yellow-500', titleColor: 'text-yellow-500', badge: '3 New', link: '/shop' },
  ];

  const getEventTypeBadge = (type: string) => {
    const styles: Record<string, string> = {
      exam: 'bg-destructive text-destructive-foreground',
      quiz: 'bg-success text-success-foreground',
      assignment: 'bg-primary text-primary-foreground',
      event: 'bg-warning text-warning-foreground',
    };
    return styles[type] || styles.event;
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'grade-increase': return <TrendingUp className="h-4 w-4 text-success" />;
      case 'achievement': return <Trophy className="h-4 w-4 text-warning" />;
      case 'purchase': return <ShoppingBag className="h-4 w-4 text-primary" />;
      case 'target-achieved': return <Target className="h-4 w-4 text-success" />;
      case 'friend-added': return <Users className="h-4 w-4 text-primary" />;
      default: return <Star className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const CustomRadarTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="font-semibold text-foreground">{payload[0].payload.fullName}</p>
          <p className="text-primary font-bold text-lg">{payload[0].value}</p>
        </div>
      );
    }
    return null;
  };

  const handleEventClick = (eventId: string) => {
    navigate(`/calendar?event=${eventId}`);
  };

  const getDaysLeft = (dateStr: string) => {
    const eventDate = new Date(dateStr);
    const today = new Date();
    const diff = Math.ceil((eventDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return Math.max(0, diff);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Profile Card */}
      <Card className="card-glow bg-card border-border overflow-hidden">
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
            <Avatar className="h-20 w-20 md:h-24 md:w-24 avatar-ring text-3xl md:text-4xl flex-shrink-0">
              {user.avatarUrl ? (
                <AvatarImage src={user.avatarUrl} alt={user.username} />
              ) : null}
              <AvatarFallback className="bg-primary text-primary-foreground font-display font-bold">
                {user.avatarLetter}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 text-center md:text-left min-w-0">
              <h2 className="font-display text-xl md:text-2xl font-bold truncate">{user.username}</h2>
              <p className="text-muted-foreground text-sm md:text-base">Grade {user.grade} {user.class && `Class ${user.class}`}</p>
              
              <div className="mt-3 md:mt-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs md:text-sm text-muted-foreground">Experience</span>
                  <span className="text-xs md:text-sm text-primary font-semibold">{user.xp} / {user.xpToNextLevel} XP</span>
                </div>
                <div className="relative h-2 md:h-3 rounded-full bg-secondary overflow-hidden">
                  <div 
                    className="h-full xp-bar rounded-full transition-all duration-500"
                    style={{ width: `${xpProgress}%` }}
                  />
                  <Zap className="absolute right-1 top-1/2 -translate-y-1/2 h-2 w-2 md:h-3 md:w-3 text-primary-foreground" />
                </div>
              </div>
            </div>

            {/* Stats Boxes */}
            <div className="flex flex-wrap justify-center md:justify-end items-center gap-2 md:gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 rounded-xl bg-primary/10 border border-primary/20">
                <span className="font-display font-bold text-primary text-base md:text-lg">{user.level}</span>
              </div>
              
              <Link to="/leaderboard">
                <div className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 rounded-xl bg-warning/10 border border-warning/20 hover:bg-warning/20 transition-colors cursor-pointer">
                  <Trophy className="h-3 w-3 md:h-4 md:w-4 text-warning" />
                  <div>
                    <p className="text-[10px] md:text-xs text-muted-foreground">Rank</p>
                    <p className="font-display font-bold text-warning text-sm md:text-base">#{userRank}</p>
                  </div>
                </div>
              </Link>
              
              <div className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 rounded-xl bg-destructive/10 border border-destructive/20">
                <Star className="h-3 w-3 md:h-4 md:w-4 text-destructive" />
                <div>
                  <p className="text-[10px] md:text-xs text-muted-foreground">Streak</p>
                  <p className="font-display font-bold text-destructive text-sm md:text-base">{user.streak} Days</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 rounded-xl bg-success/10 border border-success/20">
                <TrendingUp className="h-3 w-3 md:h-4 md:w-4 text-success" />
                <div>
                  <p className="text-[10px] md:text-xs text-muted-foreground">Progress</p>
                  <p className="font-display font-bold text-success text-sm md:text-base">+12%</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Radar Chart */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between p-4 md:p-6">
            <div>
              <CardTitle className="font-display text-lg md:text-xl">Grade Chart</CardTitle>
              <p className="text-xs md:text-sm text-muted-foreground">Hover to see scores</p>
            </div>
            <div className="text-right">
              <p className="text-xs md:text-sm text-muted-foreground">Average</p>
              <p className="font-display text-3xl md:text-4xl font-bold text-primary">{averageScore}</p>
            </div>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
              <div className="w-48 h-48 md:w-64 md:h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="hsl(var(--border))" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 8 }} />
                    <Radar
                      name="Score"
                      dataKey="score"
                      stroke="hsl(var(--primary))"
                      fill="hsl(var(--primary))"
                      fillOpacity={0.3}
                      strokeWidth={2}
                    />
                    <Tooltip content={<CustomRadarTooltip />} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              
              <div className="flex-1 space-y-2 md:space-y-3 w-full">
                {mockSubjectGrades.map(g => (
                  <div key={g.subject} className="flex items-center justify-between py-1">
                    <span className="text-xs md:text-sm">{g.subject}</span>
                    <div className="flex items-center gap-2 md:gap-3">
                      <span className="font-semibold w-6 md:w-8 text-right text-sm md:text-base">{g.currentScore}</span>
                      <span className={`text-[10px] md:text-xs font-medium w-6 md:w-8 ${
                        g.change > 0 ? 'text-success' : g.change < 0 ? 'text-destructive' : 'text-muted-foreground'
                      }`}>
                        {g.change > 0 ? `+${g.change}` : g.change}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Line Chart with Target Line synced to saved target */}
        <Card className="bg-card border-border">
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="font-display text-lg md:text-xl">Grade Progress</CardTitle>
            <p className="text-xs md:text-sm text-muted-foreground">Per subject</p>
            <div className="flex gap-1 md:gap-2 flex-wrap mt-2">
              {mockSubjectGrades.map(g => (
                <Button
                  key={g.subject}
                  variant={selectedSubject === g.subject ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedSubject(g.subject as Subject)}
                  className={`text-xs md:text-sm ${selectedSubject === g.subject ? 'gradient-primary' : ''}`}
                >
                  {g.subject}
                </Button>
              ))}
            </div>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            <div className="h-48 md:h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={selectedGrade?.history || []}>
                  <defs>
                    <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={10} />
                  <YAxis domain={[60, 100]} stroke="hsl(var(--muted-foreground))" fontSize={10} />
                  <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                  {/* Target Reference Line - synced with saved target */}
                  <ReferenceLine 
                    y={currentTarget} 
                    stroke="hsl(var(--warning))" 
                    strokeDasharray="5 5" 
                  />
                  <Area type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2} fill="url(#colorScore)" dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 3 }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            {/* Legend */}
            <div className="flex items-center justify-center gap-4 md:gap-6 mt-3 md:mt-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 md:w-4 md:h-4 rounded-full bg-primary" />
                <span className="text-xs md:text-sm text-muted-foreground">Your Score</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 md:w-4 md:h-4 rounded-full bg-warning" />
                <span className="text-xs md:text-sm text-muted-foreground">Target ({currentTarget})</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="font-display text-lg md:text-xl font-bold mb-3 md:mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 md:gap-4">
          {quickActions.map((action) => (
            <Link key={action.name} to={action.link}>
              <Card className={`bg-gradient-to-br ${action.gradient} border-border hover:border-primary/50 transition-colors cursor-pointer h-full`}>
                <CardContent className="p-3 md:p-4">
                  <div className="flex items-start justify-between mb-2 md:mb-3">
                    <div className={`p-1.5 md:p-2 rounded-lg ${action.iconBg}`}>
                      <action.icon className={`h-4 w-4 md:h-5 md:w-5 ${action.iconColor}`} />
                    </div>
                    {action.badge && (
                      <Badge variant="secondary" className={`text-[10px] md:text-xs border-0 ${action.badgeColor || 'bg-destructive/20 text-destructive'}`}>
                        {action.badge}
                      </Badge>
                    )}
                  </div>
                  <h4 className={`font-semibold text-xs md:text-sm mb-0.5 md:mb-1 ${action.titleColor}`}>{action.name}</h4>
                  <p className="text-[10px] md:text-xs text-muted-foreground line-clamp-2">{action.description}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Activity & Events Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Recent Activity */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between p-4 md:p-6">
            <CardTitle className="font-display text-lg md:text-xl">Recent Activity</CardTitle>
            <Link to="/activity">
              <Button variant="link" className="text-primary p-0 h-auto text-xs md:text-sm">View All</Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-3 md:space-y-4 p-4 md:p-6 pt-0">
            {mockActivities.map((activity) => (
              <div key={activity.id} className="flex items-start gap-2 md:gap-3">
                <div className="p-1.5 md:p-2 rounded-lg bg-secondary/50">
                  {getActivityIcon(activity.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-xs md:text-sm text-primary truncate">{activity.title}</p>
                  <p className="text-[10px] md:text-xs text-muted-foreground truncate">{activity.description}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-[10px] md:text-xs text-muted-foreground">{activity.timestamp}</p>
                  {activity.reward && (
                    <p className={`text-[10px] md:text-xs font-semibold ${activity.reward.amount > 0 ? 'text-success' : 'text-destructive'}`}>
                      {activity.reward.amount > 0 ? '+' : ''}{activity.reward.amount} {activity.reward.type === 'xp' ? 'XP' : 'Coins'}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Upcoming Events - synced with calendar */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between p-4 md:p-6">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 md:h-5 md:w-5 text-muted-foreground" />
              <CardTitle className="font-display text-lg md:text-xl">Upcoming Events</CardTitle>
            </div>
            <Link to="/calendar">
              <Button variant="link" className="text-primary p-0 h-auto text-xs md:text-sm">Calendar</Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-3 md:space-y-4 p-4 md:p-6 pt-0">
            {upcomingEvents.length === 0 ? (
              <p className="text-center text-muted-foreground text-sm py-4">No upcoming events</p>
            ) : (
              upcomingEvents.map((event) => {
                const daysLeft = getDaysLeft(event.date);
                return (
                  <div 
                    key={event.id} 
                    onClick={() => handleEventClick(event.id)}
                    className="flex items-start gap-3 md:gap-4 p-2 md:p-3 rounded-lg bg-secondary/30 border-l-2 border-primary cursor-pointer hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-xs md:text-sm truncate">{event.title}</h4>
                        <Badge className={`${getEventTypeBadge(event.type)} text-[10px] md:text-xs`}>
                          {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                        </Badge>
                      </div>
                      {event.subject && <p className="text-[10px] md:text-xs text-muted-foreground">📚 {event.subject}</p>}
                      <p className="text-[10px] md:text-xs text-muted-foreground">📅 {event.date} {event.time && `⏰ ${event.time}`}</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className={`text-xs md:text-sm font-semibold ${daysLeft <= 5 ? 'text-destructive' : daysLeft <= 10 ? 'text-warning' : 'text-success'}`}>
                        {daysLeft} days left
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;