import { mockActivities } from '@/lib/mockData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trophy, Star, TrendingUp, ShoppingBag, Users, Target, Activity, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const ActivityPage = () => {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'grade-increase': return <TrendingUp className="h-5 w-5 text-success" />;
      case 'achievement': return <Trophy className="h-5 w-5 text-warning" />;
      case 'purchase': return <ShoppingBag className="h-5 w-5 text-primary" />;
      case 'target-achieved': return <Target className="h-5 w-5 text-success" />;
      case 'friend-added': return <Users className="h-5 w-5 text-primary" />;
      default: return <Star className="h-5 w-5 text-muted-foreground" />;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-4">
        <Link to="/">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div className="flex items-center gap-3">
          <Activity className="h-8 w-8 text-primary" />
          <div>
            <h1 className="font-display text-3xl font-bold">Activity</h1>
            <p className="text-muted-foreground">Your recent activities and achievements</p>
          </div>
        </div>
      </div>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="font-display">All Activity</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {mockActivities.map((activity) => (
            <div key={activity.id} className="flex items-start gap-4 p-4 rounded-lg bg-secondary/30">
              <div className="p-3 rounded-lg bg-secondary/50">
                {getActivityIcon(activity.type)}
              </div>
              <div className="flex-1">
                <p className="font-semibold text-primary">{activity.title}</p>
                <p className="text-sm text-muted-foreground">{activity.description}</p>
                <p className="text-xs text-muted-foreground mt-1">{activity.timestamp}</p>
              </div>
              {activity.reward && (
                <div className="text-right">
                  <p className={`text-sm font-bold ${activity.reward.amount > 0 ? 'text-success' : 'text-destructive'}`}>
                    {activity.reward.amount > 0 ? '+' : ''}{activity.reward.amount}
                  </p>
                  <p className="text-xs text-muted-foreground">{activity.reward.type === 'xp' ? 'XP' : 'Coins'}</p>
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};

export default ActivityPage;