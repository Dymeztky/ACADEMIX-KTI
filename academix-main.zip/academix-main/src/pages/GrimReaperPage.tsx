import { useState } from 'react';
import { mockChallenges, mockCosmetics } from '@/lib/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skull, AlertTriangle, Clock, Users, Plus, Swords, Trophy, UserPlus, Zap, MessageCircle } from 'lucide-react';
import { toast } from 'sonner';
import type { Subject } from '@/types';
import GrimReaperChat from '@/components/GrimReaperChat';
import InviteFriendsDialog from '@/components/InviteFriendsDialog';

interface Challenge {
  id: string;
  creatorId: string;
  creatorName: string;
  subject: Subject;
  targetScore: number;
  stakedItem?: { name: string; id: string };
  stakedCoins?: number;
  estimatedValue: number;
  deadline: string;
  participants: { id: string; name: string; avatarLetter: string; score?: number }[];
  status: 'open' | 'in-progress' | 'completed';
  xpReward: number;
  winner?: string;
}

const subjects: Subject[] = ['Mathematics', 'Physics', 'Biology', 'Chemistry', 'English', 'IT'];

const GrimReaperPage = () => {
  const { user, updateUser } = useAuth();
  const [activeTab, setActiveTab] = useState('open');
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [viewParticipantsId, setViewParticipantsId] = useState<string | null>(null);
  const [chatChallengeId, setChatChallengeId] = useState<string | null>(null);
  const [inviteChallengeId, setInviteChallengeId] = useState<string | null>(null);
  
  const ownedCosmetics = mockCosmetics.filter(c => c.owned && !c.equipped);
  
  const [challenges, setChallenges] = useState<Challenge[]>([
    {
      id: '1',
      creatorId: '2',
      creatorName: 'Sarah Williams',
      subject: 'Mathematics',
      targetScore: 85,
      stakedItem: { name: 'Neon Frame', id: 'c1' },
      estimatedValue: 500,
      deadline: 'Dec 25, 2024',
      participants: [
        { id: '3', name: 'James Chen', avatarLetter: 'J' },
        { id: '4', name: 'Maya Johnson', avatarLetter: 'M' },
      ],
      status: 'open',
      xpReward: 150,
    },
    {
      id: '2',
      creatorId: '3',
      creatorName: 'James Chen',
      subject: 'Physics',
      targetScore: 80,
      stakedCoins: 300,
      estimatedValue: 300,
      deadline: 'Dec 28, 2024',
      participants: [],
      status: 'open',
      xpReward: 100,
    },
    {
      id: '3',
      creatorId: '4',
      creatorName: 'Maya Johnson',
      subject: 'Chemistry',
      targetScore: 90,
      stakedItem: { name: 'Fire Avatar', id: 'c5' },
      estimatedValue: 200,
      deadline: 'Dec 20, 2024',
      participants: [
        { id: '2', name: 'Sarah Williams', avatarLetter: 'S', score: 92 },
        { id: '5', name: 'Ryan Smith', avatarLetter: 'R', score: 88 },
      ],
      status: 'completed',
      xpReward: 180,
      winner: '2', // Sarah wins with highest score
    },
  ]);

  const [newChallenge, setNewChallenge] = useState({
    subject: '' as Subject,
    targetScore: 80,
    stakeType: 'item' as 'item' | 'coins',
    stakedItemId: '',
    stakedCoins: 100,
  });

  const calculateXpReward = (targetScore: number, estimatedValue: number) => {
    return Math.round((targetScore / 10) * 10 + (estimatedValue / 10));
  };

  // Determine winner logic
  const determineWinner = (participants: Challenge['participants'], targetScore: number) => {
    const eligibleWinners = participants.filter(p => (p.score || 0) >= targetScore);
    
    if (eligibleWinners.length === 0) {
      // Everyone loses
      return null;
    }
    
    // Winner is highest score among those who reached target
    return eligibleWinners.reduce((best, curr) => 
      (curr.score || 0) > (best.score || 0) ? curr : best
    );
  };

  const handleCreateChallenge = () => {
    if (!newChallenge.subject) {
      toast.error('Please select a subject');
      return;
    }
    
    const stakedItem = newChallenge.stakeType === 'item' 
      ? ownedCosmetics.find(c => c.id === newChallenge.stakedItemId)
      : null;

    if (newChallenge.stakeType === 'item' && !stakedItem) {
      toast.error('Please select an item to stake');
      return;
    }

    const estimatedValue = stakedItem?.price || newChallenge.stakedCoins;
    const xpReward = calculateXpReward(newChallenge.targetScore, estimatedValue);

    const challenge: Challenge = {
      id: Date.now().toString(),
      creatorId: user?.id || '1',
      creatorName: user?.username || 'You',
      subject: newChallenge.subject,
      targetScore: newChallenge.targetScore,
      stakedItem: stakedItem ? { name: stakedItem.name, id: stakedItem.id } : undefined,
      stakedCoins: newChallenge.stakeType === 'coins' ? newChallenge.stakedCoins : undefined,
      estimatedValue,
      deadline: 'Dec 30, 2024',
      participants: [],
      status: 'open',
      xpReward,
    };

    setChallenges(prev => [challenge, ...prev]);
    setNewChallenge({ subject: '' as Subject, targetScore: 80, stakeType: 'item', stakedItemId: '', stakedCoins: 100 });
    setIsCreateOpen(false);
    toast.success('Challenge created! Others can now join.');
  };

  const handleAcceptChallenge = (challengeId: string) => {
    setChallenges(prev => prev.map(c => 
      c.id === challengeId 
        ? { ...c, participants: [...c.participants, { id: user?.id || '1', name: user?.username || 'You', avatarLetter: user?.avatarLetter || 'U' }] }
        : c
    ));
    toast.success('Challenge accepted! Good luck!');
  };

  const openChallenges = challenges.filter(c => c.status === 'open');
  const inProgressChallenges = challenges.filter(c => c.status === 'in-progress');
  const completedChallenges = challenges.filter(c => c.status === 'completed');
  
  const currentChatChallenge = challenges.find(c => c.id === chatChallengeId);
  const currentInviteChallenge = challenges.find(c => c.id === inviteChallengeId);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Skull className="h-8 w-8 text-destructive" />
          <div>
            <h1 className="font-display text-3xl font-bold">Grim Reaper</h1>
            <p className="text-muted-foreground">Bet on grades, win or lose it all!</p>
          </div>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gradient-destructive">
              <Plus className="h-4 w-4 mr-2" />
              Create Challenge
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Challenge</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Subject</Label>
                <Select value={newChallenge.subject} onValueChange={(v) => setNewChallenge(prev => ({ ...prev, subject: v as Subject }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map(s => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Target Score (must beat this to win)</Label>
                <Input
                  type="number"
                  min={50}
                  max={100}
                  value={newChallenge.targetScore}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, targetScore: parseInt(e.target.value) || 80 }))}
                />
              </div>

              <div className="space-y-2">
                <Label>Stake Type</Label>
                <Select value={newChallenge.stakeType} onValueChange={(v) => setNewChallenge(prev => ({ ...prev, stakeType: v as 'item' | 'coins' }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="item">Cosmetic Item</SelectItem>
                    <SelectItem value="coins">Coins</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {newChallenge.stakeType === 'item' ? (
                <div className="space-y-2">
                  <Label>Item to Stake</Label>
                  <Select value={newChallenge.stakedItemId} onValueChange={(v) => setNewChallenge(prev => ({ ...prev, stakedItemId: v }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select item" />
                    </SelectTrigger>
                    <SelectContent>
                      {ownedCosmetics.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name} ({c.price} coins)</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label>Coins to Stake</Label>
                  <Input
                    type="number"
                    min={50}
                    max={user?.coins || 1000}
                    value={newChallenge.stakedCoins}
                    onChange={(e) => setNewChallenge(prev => ({ ...prev, stakedCoins: parseInt(e.target.value) || 100 }))}
                  />
                </div>
              )}

              <div className="p-3 rounded-lg bg-success/10 border border-success/30">
                <p className="text-sm text-success flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  Winner XP Reward: +{calculateXpReward(
                    newChallenge.targetScore, 
                    newChallenge.stakeType === 'item' 
                      ? (ownedCosmetics.find(c => c.id === newChallenge.stakedItemId)?.price || 0)
                      : newChallenge.stakedCoins
                  )} XP
                </p>
              </div>

              <div className="p-3 rounded-lg bg-muted">
                <p className="text-xs text-muted-foreground">
                  <strong>Win Condition:</strong> If everyone reaches the target score, the highest score wins. 
                  If no one reaches the target, everyone loses their stake!
                </p>
              </div>

              <Button onClick={handleCreateChallenge} className="w-full gradient-destructive">
                <Skull className="h-4 w-4 mr-2" />
                Create Challenge
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Warning Banner */}
      <Card className="bg-destructive/10 border-destructive/30">
        <CardContent className="p-4 flex items-center gap-3">
          <AlertTriangle className="h-5 w-5 text-warning" />
          <p className="text-sm text-warning font-medium">
            Warning: Items and coins you stake will be lost if you lose. Winners get extra XP!
          </p>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="open" className="flex items-center gap-2">
            <Swords className="h-4 w-4" />
            Open ({openChallenges.length})
          </TabsTrigger>
          <TabsTrigger value="in-progress" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            In Progress ({inProgressChallenges.length})
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <Trophy className="h-4 w-4" />
            History ({completedChallenges.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="open" className="space-y-4 mt-6">
          {openChallenges.length === 0 ? (
            <Card className="bg-card border-border">
              <CardContent className="p-8 text-center">
                <Skull className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">No Open Challenges</h3>
                <p className="text-muted-foreground">Create a challenge to get started!</p>
              </CardContent>
            </Card>
          ) : (
            openChallenges.map((challenge) => (
              <Card key={challenge.id} className="bg-card border-border hover:border-destructive/50 transition-colors">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-destructive text-destructive-foreground font-semibold">
                          {challenge.creatorName.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold">{challenge.creatorName}</h3>
                        <p className="text-sm text-muted-foreground">
                          challenges in <span className="text-primary">{challenge.subject}</span>
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Target: {challenge.targetScore}+ to win
                        </p>
                      </div>
                    </div>
                    <Badge className="bg-success/20 text-success border-0">
                      <Zap className="h-3 w-3 mr-1" />
                      +{challenge.xpReward} XP
                    </Badge>
                  </div>

                  <div className="mt-4 p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground mb-1">Staked</p>
                    <div className="flex items-center justify-between">
                      <p className="font-semibold">{challenge.stakedItem?.name || `${challenge.stakedCoins} Coins`}</p>
                      <p className="text-sm font-medium text-success">≈ {challenge.estimatedValue} Coins</p>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center gap-4">
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {challenge.deadline}
                      </span>
                      <button 
                        className="flex items-center gap-1 hover:text-primary transition-colors"
                        onClick={() => setViewParticipantsId(viewParticipantsId === challenge.id ? null : challenge.id)}
                      >
                        <Users className="h-4 w-4" />
                        {challenge.participants.length} joined
                      </button>
                    </div>
                    <div className="flex gap-2">
                      {challenge.creatorId !== user?.id && (
                        <Button 
                          onClick={() => handleAcceptChallenge(challenge.id)}
                          className="gradient-destructive"
                          disabled={challenge.participants.some(p => p.id === user?.id)}
                        >
                          <Swords className="h-4 w-4 mr-2" />
                          {challenge.participants.some(p => p.id === user?.id) ? 'Joined' : 'Accept'}
                        </Button>
                      )}
                      <Button 
                        variant="outline"
                        onClick={() => setInviteChallengeId(challenge.id)}
                      >
                        <UserPlus className="h-4 w-4 mr-2" />
                        Invite
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => setChatChallengeId(challenge.id)}
                      >
                        <MessageCircle className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Participants List */}
                  {viewParticipantsId === challenge.id && challenge.participants.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <p className="text-sm font-medium mb-2">Participants:</p>
                      <div className="flex flex-wrap gap-2">
                        {challenge.participants.map(p => (
                          <div key={p.id} className="flex items-center gap-2 px-3 py-1 rounded-full bg-secondary">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback className="text-xs">{p.avatarLetter}</AvatarFallback>
                            </Avatar>
                            <span className="text-sm">{p.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="in-progress" className="mt-6">
          <Card className="bg-card border-border">
            <CardContent className="p-8 text-center">
              <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">No Active Challenges</h3>
              <p className="text-muted-foreground">Accept a challenge to get started!</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4 mt-6">
          {completedChallenges.length === 0 ? (
            <Card className="bg-card border-border">
              <CardContent className="p-8 text-center">
                <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">No Challenge History</h3>
                <p className="text-muted-foreground">Complete challenges to see your history.</p>
              </CardContent>
            </Card>
          ) : (
            completedChallenges.map((challenge) => {
              const winner = challenge.participants.find(p => p.id === challenge.winner);
              const allLost = !challenge.winner;
              
              return (
                <Card key={challenge.id} className="bg-card border-border">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-4">
                        <Avatar className="h-12 w-12">
                          <AvatarFallback className="bg-muted">
                            {challenge.creatorName.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold">{challenge.creatorName}'s Challenge</h3>
                          <p className="text-sm text-muted-foreground">
                            {challenge.subject} • Target: {challenge.targetScore}+
                          </p>
                        </div>
                      </div>
                      {allLost ? (
                        <Badge className="bg-destructive/20 text-destructive border-0">
                          <Skull className="h-3 w-3 mr-1" />
                          Everyone Lost
                        </Badge>
                      ) : (
                        <Badge className="bg-success/20 text-success border-0">
                          <Trophy className="h-3 w-3 mr-1" />
                          {winner?.name} Won
                        </Badge>
                      )}
                    </div>
                    
                    {/* Participant scores */}
                    <div className="mt-4 space-y-2">
                      {challenge.participants.map(p => (
                        <div key={p.id} className="flex items-center justify-between p-2 rounded-lg bg-secondary/30">
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback className="text-xs">{p.avatarLetter}</AvatarFallback>
                            </Avatar>
                            <span className="text-sm">{p.name}</span>
                            {p.id === challenge.winner && <Trophy className="h-4 w-4 text-warning" />}
                          </div>
                          <span className={`font-semibold ${
                            (p.score || 0) >= challenge.targetScore ? 'text-success' : 'text-destructive'
                          }`}>
                            {p.score || 'N/A'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </TabsContent>
      </Tabs>

      {/* Chat Modal */}
      {chatChallengeId && currentChatChallenge && (
        <GrimReaperChat
          challengeId={chatChallengeId}
          challengeName={`${currentChatChallenge.creatorName}'s ${currentChatChallenge.subject} Challenge`}
          isOpen={!!chatChallengeId}
          onClose={() => setChatChallengeId(null)}
        />
      )}

      {/* Invite Friends Modal */}
      {inviteChallengeId && currentInviteChallenge && (
        <InviteFriendsDialog
          isOpen={!!inviteChallengeId}
          onClose={() => setInviteChallengeId(null)}
          challengeId={inviteChallengeId}
          challengeName={`${currentInviteChallenge.creatorName}'s ${currentInviteChallenge.subject} Challenge`}
        />
      )}
    </div>
  );
};

export default GrimReaperPage;
