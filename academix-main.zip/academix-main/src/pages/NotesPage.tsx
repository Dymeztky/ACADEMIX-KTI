import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { StickyNote, Plus, Search, Trash2, FileText, X, Save } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { Note, Subject } from '@/types';

const subjects: Subject[] = ['Mathematics', 'Physics', 'Biology', 'Chemistry', 'English', 'IT'];

const NotesPage = () => {
  const [notes, setNotes] = useState<Note[]>([
    { id: '1', userId: '1', title: 'Quadratic Equations', content: 'The quadratic formula: x = (-b ± √(b²-4ac)) / 2a Used to solve quadratic equations of the form ax² + bx + c = 0', subject: 'Mathematics', createdAt: '2024-01-15', updatedAt: '2024-01-15' },
    { id: '2', userId: '1', title: "Newton's Laws of Motion", content: "1. An object at rest stays at rest 2. F = ma (Force = mass × acceleration) 3. For every action there is an equal and opposite reaction", subject: 'Physics', createdAt: '2024-01-14', updatedAt: '2024-01-14' },
  ]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  
  // New note form state
  const [isCreating, setIsCreating] = useState(false);
  const [newNote, setNewNote] = useState({ title: '', content: '', subject: 'General' });

  const filteredNotes = notes.filter(n => {
    const matchesSearch = n.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = selectedSubject === 'all' || n.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  const handleCreateNote = () => {
    if (!newNote.title.trim()) {
      toast.error('Please enter a title');
      return;
    }

    const note: Note = {
      id: Date.now().toString(),
      userId: '1',
      title: newNote.title,
      content: newNote.content,
      subject: newNote.subject as Subject,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setNotes(prev => [note, ...prev]);
    setNewNote({ title: '', content: '', subject: 'General' });
    setIsCreating(false);
    setSelectedNote(note);
    toast.success('Note created!');
  };

  const handleDeleteNote = (noteId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes(prev => prev.filter(n => n.id !== noteId));
    if (selectedNote?.id === noteId) {
      setSelectedNote(null);
    }
    toast.success('Note deleted');
  };

  const handleCancelCreate = () => {
    setIsCreating(false);
    setNewNote({ title: '', content: '', subject: 'General' });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <StickyNote className="h-8 w-8 text-primary" />
          <div>
            <h1 className="font-display text-3xl font-bold">Notes</h1>
            <p className="text-muted-foreground">Create and organise your study notes</p>
          </div>
        </div>
        
        <Button 
          onClick={() => { setIsCreating(true); setSelectedNote(null); }} 
          className="gradient-primary"
        >
          <Plus className="h-4 w-4 mr-2" />
          New Note
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-14rem)]">
        {/* Left Sidebar - Notes List */}
        <div className="flex flex-col gap-4 h-full">
          {/* Search */}
          <div className="relative flex-shrink-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search notes by title..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Subject Filter */}
          <Select value={selectedSubject} onValueChange={setSelectedSubject}>
            <SelectTrigger className="flex-shrink-0">
              <SelectValue placeholder="All Subjects" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Subjects</SelectItem>
              {subjects.map(s => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Notes List */}
          <ScrollArea className="flex-1">
            <div className="space-y-3 pr-4">
              {filteredNotes.map((note) => (
                <Card 
                  key={note.id} 
                  className={`bg-card border-border hover:border-primary/50 transition-colors cursor-pointer ${
                    selectedNote?.id === note.id && !isCreating ? 'border-primary' : ''
                  }`}
                  onClick={() => { setSelectedNote(note); setIsCreating(false); }}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-1">
                      <h3 className="font-semibold text-sm">{note.title}</h3>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-6 w-6 text-destructive hover:text-destructive"
                        onClick={(e) => handleDeleteNote(note.id, e)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    {note.subject && (
                      <p className="text-xs text-primary font-medium mb-2">{note.subject}</p>
                    )}
                    <p className="text-xs text-muted-foreground line-clamp-2">{note.content}</p>
                    <p className="text-xs text-muted-foreground mt-3">
                      Updated: {new Date(note.updatedAt).toLocaleDateString()}
                    </p>
                  </CardContent>
                </Card>
              ))}

              {filteredNotes.length === 0 && (
                <Card className="bg-card border-border">
                  <CardContent className="p-8 text-center">
                    <StickyNote className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="font-semibold text-lg mb-2">No notes found</h3>
                    <p className="text-muted-foreground">Create your first note!</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Right Panel - Note Content or Create Form */}
        <Card className="lg:col-span-2 bg-card border-border flex flex-col h-full overflow-hidden">
          <CardContent className="p-0 flex-1 flex flex-col overflow-hidden">
            {isCreating ? (
              // Create New Note Form
              <ScrollArea className="flex-1">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="font-display text-xl font-bold">New Note</h2>
                    <div className="flex gap-2">
                      <Button variant="ghost" onClick={handleCancelCreate}>
                        <X className="h-4 w-4 mr-2" />
                        Cancel
                      </Button>
                      <Button onClick={handleCreateNote} className="gradient-primary">
                        <Save className="h-4 w-4 mr-2" />
                        Save
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <Input
                      value={newNote.title}
                      onChange={(e) => setNewNote(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Note title..."
                      className="text-lg font-semibold border-primary/50 focus:border-primary"
                    />
                    
                    <Select 
                      value={newNote.subject} 
                      onValueChange={(v) => setNewNote(prev => ({ ...prev, subject: v }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select subject" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="General">General</SelectItem>
                        {subjects.map(s => (
                          <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Textarea
                      value={newNote.content}
                      onChange={(e) => setNewNote(prev => ({ ...prev, content: e.target.value }))}
                      placeholder="Write your note here..."
                      className="min-h-[300px] resize-none"
                    />
                  </div>
                </div>
              </ScrollArea>
            ) : selectedNote ? (
              // View Selected Note
              <ScrollArea className="flex-1">
                <div className="p-6">
                  <div className="mb-4">
                    <h2 className="font-display text-2xl font-bold">{selectedNote.title}</h2>
                    {selectedNote.subject && (
                      <p className="text-primary font-medium">{selectedNote.subject}</p>
                    )}
                  </div>
                  <div className="prose prose-invert max-w-none">
                    <p className="text-foreground whitespace-pre-wrap">{selectedNote.content}</p>
                  </div>
                  <p className="text-sm text-muted-foreground mt-6">
                    Last updated: {new Date(selectedNote.updatedAt).toLocaleDateString()}
                  </p>
                </div>
              </ScrollArea>
            ) : (
              // Empty State
              <div className="flex flex-col items-center justify-center h-full p-8">
                <FileText className="h-16 w-16 text-primary/50 mb-4" />
                <h3 className="font-display text-xl font-bold mb-2">Select a Note</h3>
                <p className="text-muted-foreground text-center">
                  Choose a note from the list or create a new one
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NotesPage;