import { useState } from 'react';
import { mockGoals, mockSubjectGrades, predictNextScore, roadmapMilestones, calculateXpReward, calculateCoins, getXpForLevel } from '@/lib/mockData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Target, Sparkles, ClipboardList, Coins, Zap, Save, Check, Gift, Star } from 'lucide-react';
import { toast } from 'sonner';
import { useTargets } from '@/contexts/TargetContext';
import { useAuth } from '@/contexts/AuthContext';
import type { Subject } from '@/types';

const TargetPage = () => {
  const { targets, setTarget: setContextTarget, getTarget } = useTargets();
  const { user, updateUser } = useAuth();
  const [goals, setGoals] = useState(() => 
    mockGoals.map(g => ({
      ...g,
      targetScore: getTarget(g.subject as Subject),
    }))
  );
  const [savedTargets, setSavedTargets] = useState<Record<string, boolean>>({});
  const [claimedMilestones, setClaimedMilestones] = useState<number[]>(() => {
    const stored = localStorage.getItem('academix_claimed_milestones');
    return stored ? JSON.parse(stored) : [];
  });

  const onTrackCount = goals.filter(g => g.status === 'on-track').length;
  const remainingTests = 3;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'on-track':
        return <Badge className="bg-success text-success-foreground">On Track</Badge>;
      case 'needs-effort':
        return <Badge className="bg-warning text-warning-foreground">Needs Effort</Badge>;
      case 'behind':
        return <Badge className="bg-destructive text-destructive-foreground">Behind</Badge>;
      default:
        return null;
    }
  };

  const updateTarget = (goalId: string, newTarget: number, subject: Subject) => {
    setGoals(prev => prev.map(g => {
      if (g.id === goalId) {
        const minNeeded = Math.max(0, Math.min(100, Math.round((newTarget * 2) - g.currentScore)));
        const status = g.currentScore >= newTarget ? 'on-track' : minNeeded > 100 ? 'behind' : 'needs-effort';
        return { ...g, targetScore: newTarget, minNeeded, status };
      }
      return g;
    }));
    setSavedTargets(prev => ({ ...prev, [goalId]: false }));
  };

  const saveTarget = (goalId: string, subject: Subject, targetScore: number) => {
    setContextTarget(subject, targetScore);
    setSavedTargets(prev => ({ ...prev, [goalId]: true }));
    toast.success(`Target for ${subject} saved: ${targetScore}`);
    
    setTimeout(() => {
      setSavedTargets(prev => ({ ...prev, [goalId]: false }));
    }, 2000);
  };

  const handleClaimMilestone = (level: number) => {
    if (!user || claimedMilestones.includes(level)) return;
    
    const milestone = roadmapMilestones.find(m => m.level === level);
    if (!milestone || (user.level || 1) < level) return;

    const newClaimedMilestones = [...claimedMilestones, level];
    setClaimedMilestones(newClaimedMilestones);
    localStorage.setItem('academix_claimed_milestones', JSON.stringify(newClaimedMilestones));

    // Add rewards
    updateUser({
      xp: (user.xp || 0) + milestone.rewards.xp,
      coins: (user.coins || 0) + milestone.rewards.coins,
    });

    toast.success(`Claimed Level ${level} rewards: +${milestone.rewards.xp} XP, +${milestone.rewards.coins} Coins, ${milestone.rewards.item}!`);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-3">
        <Target className="h-8 w-8 text-primary" />
        <div>
          <h1 className="font-display text-3xl font-bold">Goal Setting</h1>
          <p className="text-muted-foreground">Set your grade targets and track progress</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-warning/20">
              <ClipboardList className="h-6 w-6 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Remaining Tests</p>
              <p className="font-display text-2xl font-bold">{remainingTests} Tests</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-success/20">
              <Sparkles className="h-6 w-6 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">On Track</p>
              <p className="font-display text-2xl font-bold">{onTrackCount} / {goals.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {goals.map((goal) => {
          const grade = mockSubjectGrades.find(g => g.subject === goal.subject);
          const predicted = grade ? predictNextScore(grade.history) : goal.predictedScore;
          const progressPercent = Math.min(100, (goal.currentScore / goal.targetScore) * 100);
          
          // XP gained: 25% of needed XP to level up (if target is reached)
          const xpReward = calculateXpReward(user?.xp || 0, user?.xpToNextLevel || 100);
          
          // Coins: Only if target is above current score
          // Formula: 10 * max(next_score - max(target_score, predicted_score), 0)
          const coinsReward = goal.targetScore > goal.currentScore 
            ? calculateCoins(goal.targetScore, goal.currentScore, predicted) 
            : 0;
          
          return (
            <Card key={goal.id} className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="font-display text-xl">{goal.subject}</CardTitle>
                {getStatusBadge(goal.status)}
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Progress Bar with animated target line */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Progress to Target</span>
                    <span className="text-sm font-semibold">{goal.currentScore} / {goal.targetScore}</span>
                  </div>
                  <div className="h-3 rounded-full bg-secondary overflow-hidden relative">
                    <div 
                      className="h-full rounded-full transition-all duration-700 ease-out"
                      style={{ 
                        width: `${progressPercent}%`,
                        background: progressPercent >= 100 
                          ? 'linear-gradient(90deg, hsl(var(--success)) 0%, hsl(var(--success)) 100%)'
                          : progressPercent >= 80
                          ? 'linear-gradient(90deg, hsl(var(--primary)) 0%, hsl(162, 87%, 50%) 50%, hsl(50, 100%, 50%) 100%)'
                          : 'linear-gradient(90deg, hsl(var(--primary)) 0%, hsl(162, 87%, 50%) 100%)'
                      }}
                    />
                    {/* Animated target line */}
                    <div 
                      className="absolute inset-y-0 w-0.5 bg-warning transition-all duration-500 ease-out"
                      style={{ left: `${Math.min(100, goal.targetScore)}%` }}
                    />
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground mb-1">Current</p>
                    <p className="font-display text-2xl font-bold text-primary">{goal.currentScore}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground mb-1">Predicted</p>
                    <p className="font-display text-2xl font-bold text-success">{predicted}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground mb-1">Min. Needed</p>
                    <p className={`font-display text-2xl font-bold ${
                      goal.minNeeded > 100 ? 'text-destructive' : goal.minNeeded > goal.currentScore ? 'text-warning' : 'text-success'
                    }`}>
                      {goal.minNeeded > 100 ? '100+' : goal.minNeeded}
                    </p>
                  </div>
                </div>

                {/* Rewards - XP is 25% of needed, Coins only if target > current */}
                <div className="p-3 rounded-lg bg-secondary/30">
                  <div className="flex items-center justify-center gap-6">
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4 text-primary" />
                      <span className="font-semibold text-primary">+{xpReward} XP</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Coins className="h-4 w-4 text-warning" />
                      <span className={`font-semibold ${coinsReward > 0 ? 'text-warning' : 'text-muted-foreground'}`}>
                        {coinsReward > 0 ? `+${coinsReward}` : '0'} Coins
                      </span>
                    </div>
                  </div>
                  {coinsReward === 0 && goal.targetScore <= goal.currentScore && (
                    <p className="text-xs text-muted-foreground text-center mt-2">
                      Set target above current score to earn coins
                    </p>
                  )}
                </div>

                {/* Target Slider */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Set Target</span>
                    <span className="text-sm font-semibold text-primary">{goal.targetScore}</span>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-0 h-2 top-1/2 -translate-y-1/2 rounded-full overflow-hidden pointer-events-none">
                      <div 
                        className="h-full transition-all duration-300"
                        style={{
                          background: 'linear-gradient(90deg, hsl(var(--primary)) 0%, hsl(162, 87%, 50%) 50%, hsl(50, 100%, 50%) 100%)',
                          width: `${((goal.targetScore - 50) / 50) * 100}%`
                        }}
                      />
                    </div>
                    <Slider
                      value={[goal.targetScore]}
                      onValueChange={(value) => updateTarget(goal.id, value[0], goal.subject as Subject)}
                      min={50}
                      max={100}
                      step={1}
                      className="cursor-pointer"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-muted-foreground">
                      You need at least {goal.minNeeded > 100 ? 'a perfect score' : goal.minNeeded} on your next test
                    </p>
                    <Button
                      size="sm"
                      variant={savedTargets[goal.id] ? 'default' : 'outline'}
                      onClick={() => saveTarget(goal.id, goal.subject as Subject, goal.targetScore)}
                      className={savedTargets[goal.id] ? 'bg-success hover:bg-success/90' : ''}
                    >
                      {savedTargets[goal.id] ? (
                        <>
                          <Check className="h-3 w-3 mr-1" />
                          Saved
                        </>
                      ) : (
                        <>
                          <Save className="h-3 w-3 mr-1" />
                          Save
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Roadmap Section */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="font-display flex items-center gap-2">
            <Gift className="h-5 w-5 text-warning" />
            Level Roadmap
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            {/* Progress line */}
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-border" />
            
            <div className="space-y-6">
              {roadmapMilestones.map((milestone, index) => {
                const isReached = (user?.level || 1) >= milestone.level;
                const isClaimed = claimedMilestones.includes(milestone.level);
                const canClaim = isReached && !isClaimed;
                
                return (
                  <div key={milestone.level} className="flex items-center gap-4 relative">
                    <button
                      onClick={() => canClaim && handleClaimMilestone(milestone.level)}
                      disabled={!canClaim && !isClaimed}
                      className={`w-12 h-12 rounded-full flex items-center justify-center z-10 transition-all ${
                        isClaimed 
                          ? 'bg-warning/30 border-2 border-warning' 
                          : isReached 
                          ? 'bg-warning text-warning-foreground cursor-pointer hover:scale-110 shadow-lg shadow-warning/50' 
                          : 'bg-secondary text-muted-foreground'
                      }`}
                    >
                      <Star className={`h-5 w-5 ${
                        isClaimed 
                          ? 'text-warning/60' 
                          : isReached 
                          ? 'text-warning-foreground animate-pulse' 
                          : ''
                      }`} />
                    </button>
                    
                    <div className={`flex-1 p-4 rounded-lg ${
                      isClaimed 
                        ? 'bg-warning/10 border border-warning/30' 
                        : isReached 
                        ? 'bg-success/10 border border-success/30' 
                        : 'bg-secondary/30'
                    }`}>
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-semibold">Level {milestone.level}</p>
                        <div className="flex items-center gap-2">
                          {isClaimed && <Badge className="bg-warning/20 text-warning">Claimed</Badge>}
                          {canClaim && (
                            <Button size="sm" className="gradient-warning text-xs" onClick={() => handleClaimMilestone(milestone.level)}>
                              Claim
                            </Button>
                          )}
                          {!isReached && <Badge variant="secondary">Locked</Badge>}
                        </div>
                      </div>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="flex items-center gap-1">
                          <Zap className="h-3 w-3 text-primary" />
                          +{milestone.rewards.xp} XP
                        </span>
                        <span className="flex items-center gap-1">
                          <Coins className="h-3 w-3 text-warning" />
                          +{milestone.rewards.coins} Coins
                        </span>
                        <span className="flex items-center gap-1">
                          <Gift className="h-3 w-3 text-purple-400" />
                          {milestone.rewards.item}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        XP needed: {getXpForLevel(milestone.level)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TargetPage;