import { useState } from 'react';
import { mockCosmetics, itemValues } from '@/lib/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Input } from '@/components/ui/input';
import { Package, Sparkles, DollarSign, Gem, ArrowUpDown, Search } from 'lucide-react';
import { toast } from 'sonner';

interface InventoryItem {
  id: string;
  name: string;
  rarity: string;
  price: number;
  owned: boolean;
  equipped: boolean;
  quantity: number;
}

const InventoryPage = () => {
  const { user, updateUser } = useAuth();
  const [activeTab, setActiveTab] = useState('all');
  const [sortOrder, setSortOrder] = useState<'low-high' | 'high-low'>('low-high');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    return mockCosmetics.filter(c => c.owned).map(c => ({
      id: c.id,
      name: c.name,
      rarity: c.rarity,
      price: c.price,
      owned: c.owned,
      equipped: c.equipped,
      quantity: Math.floor(Math.random() * 3) + 1,
    }));
  });

  // Calculate total item value and count
  const totalItemValue = inventory.reduce((sum, c) => sum + (itemValues[c.rarity] || 50) * c.quantity, 0);
  const totalItemCount = inventory.reduce((sum, c) => sum + c.quantity, 0);

  const getFilteredItems = () => {
    let filtered = inventory;
    
    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(c => 
        c.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    // Rarity filter
    if (activeTab !== 'all') {
      filtered = filtered.filter(c => c.rarity === activeTab);
    }

    // Sort
    filtered.sort((a, b) => {
      const priceA = itemValues[a.rarity] || 50;
      const priceB = itemValues[b.rarity] || 50;
      return sortOrder === 'low-high' ? priceA - priceB : priceB - priceA;
    });

    return filtered;
  };

  const filteredItems = getFilteredItems();

  const handleEquip = (itemId: string) => {
    setInventory(prev => prev.map(c => {
      if (c.id === itemId) {
        return { ...c, equipped: !c.equipped };
      }
      return c;
    }));
    toast.success('Item equipped!');
  };

  const handleSell = (itemId: string) => {
    const item = inventory.find(c => c.id === itemId);
    if (!item || !user) return;

    const sellPrice = Math.floor((itemValues[item.rarity] || 50) * 0.5);
    
    if (item.quantity > 1) {
      setInventory(prev => prev.map(c => 
        c.id === itemId ? { ...c, quantity: c.quantity - 1 } : c
      ));
    } else {
      // Remove item completely when quantity reaches 0
      setInventory(prev => prev.filter(c => c.id !== itemId));
    }
    
    updateUser({ coins: user.coins + sellPrice });
    toast.success(`Sold ${item.name} for ${sellPrice} coins!`);
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'mythical': return 'text-pink-400 border-pink-400/50 bg-pink-400/10';
      case 'legendary': return 'text-warning border-warning/50 bg-warning/10';
      case 'epic': return 'text-purple-400 border-purple-400/50 bg-purple-400/10';
      case 'rare': return 'text-primary border-primary/50 bg-primary/10';
      case 'uncommon': return 'text-green-400 border-green-400/50 bg-green-400/10';
      default: return 'text-muted-foreground border-border bg-secondary/30';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Package className="h-8 w-8 text-primary" />
          <div>
            <h1 className="font-display text-3xl font-bold">Inventory</h1>
            <p className="text-muted-foreground">Manage your owned items</p>
          </div>
        </div>
        
        {/* Stats */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/50 border border-border">
            <Package className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">{totalItemCount} items</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
            <Gem className="h-5 w-5 text-primary" />
            <span className="font-semibold text-primary">Total Value: {totalItemValue.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search items by name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
          <TabsList className="bg-secondary/50 flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="all" className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              All
            </TabsTrigger>
            <TabsTrigger value="common">Common</TabsTrigger>
            <TabsTrigger value="uncommon">Uncommon</TabsTrigger>
            <TabsTrigger value="rare">Rare</TabsTrigger>
            <TabsTrigger value="epic">Epic</TabsTrigger>
            <TabsTrigger value="legendary">Legendary</TabsTrigger>
            <TabsTrigger value="mythical">Mythical</TabsTrigger>
          </TabsList>
        </Tabs>

        <Select value={sortOrder} onValueChange={(v) => setSortOrder(v as 'low-high' | 'high-low')}>
          <SelectTrigger className="w-48">
            <ArrowUpDown className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Sort by value" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="low-high">Value: Low to High</SelectItem>
            <SelectItem value="high-low">Value: High to Low</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filteredItems.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredItems.map((item) => (
            <Card 
              key={item.id} 
              className={`bg-card border-border hover:border-primary/50 transition-colors ${
                item.equipped ? 'ring-2 ring-primary' : ''
              }`}
            >
              <CardContent className="p-4">
                <div className={`aspect-square rounded-lg mb-4 flex items-center justify-center relative ${getRarityColor(item.rarity)}`}>
                  <Gem className="h-8 w-8" />
                  {item.quantity > 1 && (
                    <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs font-bold px-2 py-0.5 rounded-full">
                      x{item.quantity}
                    </div>
                  )}
                </div>
                
                <h3 className="font-semibold text-sm mb-1">{item.name}</h3>
                <div className="flex items-center justify-between mb-2">
                  <p className={`text-xs capitalize ${
                    item.rarity === 'mythical' ? 'text-pink-400' :
                    item.rarity === 'legendary' ? 'text-warning' :
                    item.rarity === 'epic' ? 'text-purple-400' :
                    item.rarity === 'rare' ? 'text-primary' :
                    item.rarity === 'uncommon' ? 'text-green-400' :
                    'text-muted-foreground'
                  }`}>
                    {item.rarity}
                  </p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Gem className="h-3 w-3" />
                    {itemValues[item.rarity] || 50}
                  </p>
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    variant={item.equipped ? 'default' : 'outline'}
                    size="sm" 
                    className="flex-1"
                    onClick={() => handleEquip(item.id)}
                  >
                    {item.equipped ? 'Equipped' : 'Equip'}
                  </Button>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button 
                          variant="outline"
                          size="sm"
                          onClick={() => handleSell(item.id)}
                          disabled={item.equipped}
                          className="text-warning hover:text-warning"
                        >
                          <DollarSign className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Sell for {Math.floor((itemValues[item.rarity] || 50) * 0.5)} coins</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-card border-border">
          <CardContent className="p-8 text-center">
            <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="font-semibold text-lg mb-2">No items found</h3>
            <p className="text-muted-foreground">Visit the shop to get new items!</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default InventoryPage;