import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar as CalendarIcon, Plus, ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isToday, isSameDay } from 'date-fns';
import { toast } from 'sonner';
import { useCalendar } from '@/contexts/CalendarContext';
import type { Subject } from '@/types';

const subjects: Subject[] = ['Mathematics', 'Physics', 'Biology', 'Chemistry', 'English', 'IT'];
const eventTypes = ['Study Session', 'Exam', 'Quiz', 'Assignment', 'Event'] as const;

const CalendarPage = () => {
  const { events, addEvent } = useCalendar();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [viewEventDialog, setViewEventDialog] = useState<typeof events[0] | null>(null);
  const [newEvent, setNewEvent] = useState({
    title: '',
    subject: '',
    type: 'Study Session' as typeof eventTypes[number],
    time: '09:00',
    notes: '',
  });

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const startPadding = monthStart.getDay();
  const paddedDays = [...Array(startPadding).fill(null), ...days];

  const getEventTypeBadge = (type: string) => {
    const styles: Record<string, string> = {
      exam: 'bg-destructive text-destructive-foreground',
      quiz: 'bg-success text-success-foreground',
      assignment: 'bg-primary text-primary-foreground',
      event: 'bg-warning text-warning-foreground',
      'study session': 'bg-primary text-primary-foreground',
    };
    return styles[type.toLowerCase()] || styles.event;
  };

  const getEventsForDate = (date: Date) => {
    return events.filter(event => {
      const eventDate = new Date(event.date);
      return isSameDay(eventDate, date);
    });
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setIsDialogOpen(true);
  };

  const handleCreateEvent = () => {
    if (!newEvent.title || !selectedDate) {
      toast.error('Please fill in the event title');
      return;
    }

    const eventDate = selectedDate;
    const today = new Date();
    const daysLeft = Math.ceil((eventDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    const event = {
      id: Date.now().toString(),
      title: newEvent.title,
      subject: newEvent.subject as Subject,
      type: newEvent.type.toLowerCase() as 'exam' | 'quiz' | 'assignment' | 'event',
      date: format(selectedDate, 'yyyy-MM-dd'),
      time: newEvent.time,
      daysLeft: Math.max(0, daysLeft),
      notes: newEvent.notes,
    };

    addEvent(event);
    setNewEvent({ title: '', subject: '', type: 'Study Session', time: '09:00', notes: '' });
    setIsDialogOpen(false);
    toast.success('Event created!');
  };

  // Upcoming events sorted by nearest date
  const upcomingEvents = events
    .filter(e => new Date(e.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-3">
        <CalendarIcon className="h-8 w-8 text-primary" />
        <div>
          <h1 className="font-display text-3xl font-bold">My Schedule</h1>
          <p className="text-muted-foreground">Manage your academic calendar and activities</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Grid */}
        <Card className="lg:col-span-2 bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <Button 
              variant="ghost"
              onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
              className="flex items-center gap-1"
            >
              <ChevronLeft className="h-4 w-4" />
              Previous
            </Button>
            <CardTitle className="font-display text-xl">
              {format(currentMonth, 'MMMM yyyy')}
            </CardTitle>
            <Button 
              variant="ghost"
              onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
              className="flex items-center gap-1"
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            {/* Day Headers */}
            <div className="grid grid-cols-7 gap-1 mb-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="text-center text-sm font-medium text-muted-foreground py-2">
                  {day}
                </div>
              ))}
            </div>
            
            {/* Calendar Days */}
            <div className="grid grid-cols-7 gap-1">
              {paddedDays.map((day, index) => {
                if (!day) {
                  return <div key={`empty-${index}`} className="aspect-square" />;
                }
                
                const dayEvents = getEventsForDate(day);
                const hasEvents = dayEvents.length > 0;
                
                return (
                  <button
                    key={day.toISOString()}
                    onClick={() => handleDateClick(day)}
                    className={`aspect-square rounded-lg p-1 text-sm transition-all relative hover:bg-primary/20 ${
                      isToday(day) 
                        ? 'bg-primary text-primary-foreground font-bold ring-2 ring-primary ring-offset-2 ring-offset-background' 
                        : 'hover:bg-secondary/50'
                    }`}
                  >
                    <span>{format(day, 'd')}</span>
                    {hasEvents && (
                      <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-0.5">
                        {dayEvents.slice(0, 3).map((e, i) => (
                          <div 
                            key={i} 
                            className={`h-1.5 w-1.5 rounded-full ${
                              e.type === 'exam' ? 'bg-destructive' :
                              e.type === 'quiz' ? 'bg-success' :
                              e.type === 'assignment' ? 'bg-primary' : 'bg-warning'
                            }`}
                          />
                        ))}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Events */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              Upcoming Events
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 max-h-[500px] overflow-y-auto">
            {upcomingEvents.length === 0 ? (
              <div className="text-center py-8">
                <CalendarIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No upcoming events</p>
                <p className="text-sm text-muted-foreground">Click on a date to add events</p>
              </div>
            ) : (
              upcomingEvents.map((event) => {
                const daysLeft = Math.ceil((new Date(event.date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                return (
                  <div 
                    key={event.id} 
                    className="p-4 rounded-lg bg-secondary/30 border-l-2 border-primary cursor-pointer hover:bg-secondary/50 transition-colors"
                    onClick={() => setViewEventDialog(event)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-sm">{event.title}</h4>
                      <Badge className={getEventTypeBadge(event.type)}>
                        {event.type}
                      </Badge>
                    </div>
                    {event.subject && (
                      <p className="text-xs text-muted-foreground">📚 {event.subject}</p>
                    )}
                    <p className="text-xs text-muted-foreground">📅 {event.date} ⏰ {event.time}</p>
                    {event.notes && (
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-1">📝 {event.notes}</p>
                    )}
                    <p className={`text-xs font-medium mt-2 ${
                      daysLeft <= 5 ? 'text-destructive' : daysLeft <= 10 ? 'text-warning' : 'text-success'
                    }`}>
                      {daysLeft} days left
                    </p>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>
      </div>

      {/* Create Event Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedDate && format(selectedDate, 'EEEE, MMMM d, yyyy')}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Title</Label>
              <Input
                value={newEvent.title}
                onChange={(e) => setNewEvent(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Event title..."
                className="border-primary/50 focus:border-primary"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Time</Label>
                <Input
                  type="time"
                  value={newEvent.time}
                  onChange={(e) => setNewEvent(prev => ({ ...prev, time: e.target.value }))}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Type</Label>
                <Select 
                  value={newEvent.type} 
                  onValueChange={(v) => setNewEvent(prev => ({ ...prev, type: v as typeof eventTypes[number] }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {eventTypes.map(t => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Subject (Optional)</Label>
              <Input
                value={newEvent.subject}
                onChange={(e) => setNewEvent(prev => ({ ...prev, subject: e.target.value }))}
                placeholder="e.g., Mathematics"
              />
            </div>

            <div className="space-y-2">
              <Label>Notes (Optional)</Label>
              <Textarea
                value={newEvent.notes}
                onChange={(e) => setNewEvent(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="What to prepare, what to bring, etc..."
                rows={3}
              />
            </div>
            
            <Button onClick={handleCreateEvent} className="w-full gradient-primary">
              <Plus className="h-4 w-4 mr-2" />
              Add Event
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Event Dialog */}
      <Dialog open={!!viewEventDialog} onOpenChange={() => setViewEventDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{viewEventDialog?.title}</DialogTitle>
          </DialogHeader>
          {viewEventDialog && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Badge className={getEventTypeBadge(viewEventDialog.type)}>
                  {viewEventDialog.type}
                </Badge>
                {viewEventDialog.subject && (
                  <Badge variant="outline">{viewEventDialog.subject}</Badge>
                )}
              </div>
              
              <div className="space-y-2 text-sm">
                <p className="flex items-center gap-2">
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                  {viewEventDialog.date}
                </p>
                <p className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  {viewEventDialog.time}
                </p>
              </div>

              {viewEventDialog.notes && (
                <div className="p-4 rounded-lg bg-secondary/30">
                  <p className="text-sm font-medium mb-2">Notes:</p>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{viewEventDialog.notes}</p>
                </div>
              )}

              <p className={`text-sm font-medium ${
                viewEventDialog.daysLeft <= 5 ? 'text-destructive' : viewEventDialog.daysLeft <= 10 ? 'text-warning' : 'text-success'
              }`}>
                {viewEventDialog.daysLeft} days left
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CalendarPage;