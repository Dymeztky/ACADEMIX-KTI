import { useState, useRef, useEffect } from 'react';
import { mockLeaderboard, mockCosmetics, itemValues, calculateAverageScore, mockSubjectGrades } from '@/lib/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Trophy, TrendingUp, TrendingDown, Minus, Crown, Medal, Gem, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Grade } from '@/types';

type SortType = 'avgScore' | 'level' | 'itemValue';

// Generate 140 students per grade with proper data
const generateLeaderboard = (baseData: typeof mockLeaderboard, currentUser: any) => {
  const expanded = [...baseData];
  
  // Add current user if not in base data
  const userExists = baseData.some(e => e.userId === currentUser?.id);
  if (currentUser && !userExists) {
    const userAvg = calculateAverageScore(mockSubjectGrades);
    expanded.push({
      rank: 0,
      userId: currentUser.id,
      username: currentUser.username,
      avatarLetter: currentUser.avatarLetter || currentUser.username?.charAt(0) || 'U',
      averageScore: userAvg,
      level: currentUser.level || 1,
      trend: 'up' as const,
      xp: currentUser.xp || 0,
      totalCoins: (currentUser.coins || 0) + 500, // total coins earned
    });
  } else if (currentUser) {
    // Update existing user entry with current user data
    const idx = expanded.findIndex(e => e.userId === currentUser.id);
    if (idx !== -1) {
      expanded[idx] = {
        ...expanded[idx],
        username: currentUser.username,
        avatarLetter: currentUser.avatarLetter || currentUser.username?.charAt(0) || 'U',
        averageScore: calculateAverageScore(mockSubjectGrades),
        level: currentUser.level || expanded[idx].level,
        xp: currentUser.xp || 0,
        totalCoins: (currentUser.coins || 0) + 500,
      };
    }
  }

  // Add more students
  for (let i = expanded.length; i < 140; i++) {
    const names = ['Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Quinn', 'Avery', 'Sam', 'Cameron'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Davis', 'Miller', 'Wilson', 'Moore', 'Anderson'];
    const name = `${names[i % names.length]} ${lastNames[Math.floor(i / names.length) % lastNames.length]}`;
    
    // Generate with decimal precision for tiebreakers
    const baseScore = Math.max(50, 95 - Math.floor(i * 0.3));
    const decimal = Math.random() * 0.9;
    
    expanded.push({
      rank: i + 1,
      userId: `${i + 10}`,
      username: name,
      avatarLetter: name.charAt(0),
      averageScore: baseScore + decimal,
      level: Math.max(1, 30 - Math.floor(i * 0.2)),
      trend: ['up', 'down', 'stable'][i % 3] as 'up' | 'down' | 'stable',
      xp: Math.floor(Math.random() * 500),
      totalCoins: Math.floor(Math.random() * 2000) + 500,
    });
  }
  return expanded;
};

const LeaderboardPage = () => {
  const { user } = useAuth();
  const [selectedGrade, setSelectedGrade] = useState<Grade>(user?.grade as Grade || '12');
  const [sortBy, setSortBy] = useState<SortType>('avgScore');
  const myPositionRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const grades: Grade[] = ['10', '11', '12'];
  const fullLeaderboard = generateLeaderboard(mockLeaderboard, user);

  // Update selected grade when user changes
  useEffect(() => {
    if (user?.grade) {
      setSelectedGrade(user.grade as Grade);
    }
  }, [user?.grade]);

  // Calculate item values for each user
  const getItemValue = (userId: string) => {
    if (userId === user?.id) {
      const ownedItems = mockCosmetics.filter(c => c.owned);
      return ownedItems.reduce((sum, item) => sum + (itemValues[item.rarity] || 50), 0);
    }
    const baseValue = parseInt(userId) * 150;
    return baseValue + ((parseInt(userId) * 7) % 500);
  };

  // Sort leaderboard with tiebreakers
  const sortedLeaderboard = [...fullLeaderboard].sort((a, b) => {
    switch (sortBy) {
      case 'avgScore':
        // Primary: average score (higher is better)
        // Tiebreaker: decimal precision
        if (Math.floor(b.averageScore) === Math.floor(a.averageScore)) {
          return b.averageScore - a.averageScore; // Use full decimal
        }
        return b.averageScore - a.averageScore;
      case 'level':
        // Primary: level
        // Tiebreaker: XP on current level
        if (b.level === a.level) {
          return (b.xp || 0) - (a.xp || 0);
        }
        return b.level - a.level;
      case 'itemValue':
        // Primary: item value
        // Tiebreaker: total coins earned
        const valueA = getItemValue(a.userId);
        const valueB = getItemValue(b.userId);
        if (valueB === valueA) {
          return (b.totalCoins || 0) - (a.totalCoins || 0);
        }
        return valueB - valueA;
      default:
        return 0;
    }
  }).map((entry, index) => ({ ...entry, rank: index + 1 }));

  const topThree = sortedLeaderboard.slice(0, 3);
  
  // Find user's position by their ID
  const userPosition = sortedLeaderboard.findIndex(e => e.userId === user?.id) + 1;

  const scrollToMyPosition = () => {
    if (myPositionRef.current && scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const element = myPositionRef.current;
      const containerRect = container.getBoundingClientRect();
      const elementRect = element.getBoundingClientRect();
      
      const scrollTop = element.offsetTop - container.offsetTop - (containerRect.height / 2) + (elementRect.height / 2);
      
      container.scrollTo({
        top: scrollTop,
        behavior: 'smooth'
      });
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-success" />;
      case 'down':
        return <TrendingDown className="h-4 w-4 text-destructive" />;
      default:
        return <Minus className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getRankDisplay = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-warning" />;
      case 2:
        return <span className="font-display font-bold text-xl text-gray-400">2</span>;
      case 3:
        return <span className="font-display font-bold text-xl text-orange-400">3</span>;
      default:
        return <span className="text-muted-foreground font-semibold">#{rank}</span>;
    }
  };

  const getPodiumStyles = (rank: number) => {
    switch (rank) {
      case 1:
        return {
          avatarSize: 'h-20 w-20',
          avatarBg: 'bg-warning',
          podiumHeight: 'h-32',
          podiumBg: 'bg-warning/20',
          order: 'order-2',
        };
      case 2:
        return {
          avatarSize: 'h-16 w-16',
          avatarBg: 'bg-gray-400',
          podiumHeight: 'h-24',
          podiumBg: 'bg-secondary',
          order: 'order-1',
        };
      case 3:
        return {
          avatarSize: 'h-14 w-14',
          avatarBg: 'bg-orange-500',
          podiumHeight: 'h-20',
          podiumBg: 'bg-orange-500/20',
          order: 'order-3',
        };
      default:
        return {
          avatarSize: 'h-12 w-12',
          avatarBg: 'bg-primary',
          podiumHeight: 'h-16',
          podiumBg: 'bg-secondary',
          order: '',
        };
    }
  };

  const getSortValue = (entry: typeof sortedLeaderboard[0]) => {
    switch (sortBy) {
      case 'avgScore':
        return Math.round(entry.averageScore);
      case 'level':
        return entry.level;
      case 'itemValue':
        return getItemValue(entry.userId);
      default:
        return Math.round(entry.averageScore);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in relative pb-20">
      <div className="flex items-center gap-3">
        <Trophy className="h-8 w-8 text-warning" />
        <div>
          <h1 className="font-display text-3xl font-bold">Leaderboard</h1>
          <p className="text-muted-foreground">Rankings per year level</p>
        </div>
      </div>

      {/* Grade Tabs */}
      <div className="flex gap-2">
        {grades.map((grade) => (
          <Button
            key={grade}
            variant={selectedGrade === grade ? 'default' : 'outline'}
            onClick={() => setSelectedGrade(grade)}
            className={selectedGrade === grade ? 'gradient-primary' : ''}
          >
            Grade {grade}
          </Button>
        ))}
      </div>

      {/* Sort Options */}
      <div className="flex gap-2 flex-wrap">
        <span className="text-sm text-muted-foreground self-center mr-2">Sort by:</span>
        <Button
          variant={sortBy === 'avgScore' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSortBy('avgScore')}
          className={sortBy === 'avgScore' ? 'gradient-primary' : ''}
        >
          <Medal className="h-4 w-4 mr-2" />
          Avg Score
        </Button>
        <Button
          variant={sortBy === 'level' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSortBy('level')}
          className={sortBy === 'level' ? 'gradient-primary' : ''}
        >
          <TrendingUp className="h-4 w-4 mr-2" />
          Level
        </Button>
        <Button
          variant={sortBy === 'itemValue' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSortBy('itemValue')}
          className={sortBy === 'itemValue' ? 'gradient-primary' : ''}
        >
          <Gem className="h-4 w-4 mr-2" />
          Item Value
        </Button>
      </div>

      {/* Podium */}
      <Card className="bg-card border-border">
        <CardContent className="p-8">
          <div className="flex items-end justify-center gap-4">
            {topThree.map((entry) => {
              const styles = getPodiumStyles(entry.rank);
              return (
                <Link
                  key={entry.userId}
                  to={`/profile/${entry.userId}`}
                  className={`flex flex-col items-center ${styles.order} hover:opacity-80 transition-opacity`}
                >
                  <div className="relative mb-2">
                    <Avatar className={`${styles.avatarSize} border-4 border-background`}>
                      <AvatarFallback className={`${styles.avatarBg} text-background font-display font-bold text-2xl`}>
                        {entry.avatarLetter}
                      </AvatarFallback>
                    </Avatar>
                    {entry.rank === 1 && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                        <Crown className="h-8 w-8 text-warning" />
                      </div>
                    )}
                  </div>
                  
                  <div className={`w-28 ${styles.podiumHeight} ${styles.podiumBg} rounded-t-lg flex flex-col items-center justify-start pt-4`}>
                    <div className="mb-1">{getRankDisplay(entry.rank)}</div>
                    <p className="font-semibold text-sm text-center">{entry.username.split(' ')[0]}</p>
                  </div>
                </Link>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Full Rankings */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="font-display">Full Rankings - Grade {selectedGrade}</CardTitle>
        </CardHeader>
        <CardContent 
          ref={scrollContainerRef}
          className="space-y-2 max-h-[600px] overflow-y-auto"
        >
          {sortedLeaderboard.map((entry) => {
            const isCurrentUser = entry.userId === user?.id;
            return (
              <div
                key={entry.userId}
                ref={isCurrentUser ? myPositionRef : undefined}
              >
                <Link
                  to={`/profile/${entry.userId}`}
                  className={`flex items-center gap-4 p-4 rounded-lg transition-colors ${
                    isCurrentUser ? 'bg-primary/10 border border-primary/30' : 'bg-secondary/30 hover:bg-secondary/50'
                  }`}
                >
                  <div className="w-10 flex justify-center">
                    {getRankDisplay(entry.rank)}
                  </div>
                  
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-warning text-warning-foreground font-semibold">
                      {entry.avatarLetter}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <p className="font-semibold">{entry.username} {isCurrentUser && <span className="text-primary">(You)</span>}</p>
                    <p className="text-xs text-muted-foreground">Level {entry.level}</p>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <p className="font-display font-bold text-primary text-lg">{getSortValue(entry)}</p>
                    {getTrendIcon(entry.trend)}
                  </div>
                </Link>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Fixed Find Me Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button onClick={scrollToMyPosition} className="gradient-primary shadow-lg gap-2">
          <User className="h-4 w-4" />
          Find Me (#{userPosition > 0 ? userPosition : '?'})
        </Button>
      </div>
    </div>
  );
};

export default LeaderboardPage;