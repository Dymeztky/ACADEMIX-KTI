import { useState, useRef, useEffect } from 'react';
import { mockCosmetics, itemValues } from '@/lib/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { RefreshCw, Plus, Search, ArrowRight, Sparkles, Check, X, Users, MessageCircle, Send, Clock, Gem } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface TradeOffer {
  id: string;
  fromUser: string;
  fromUserId: string;
  fromAvatarLetter: string;
  offering: string;
  offeringId: string;
  offeringRarity: string;
  offeringValue: number;
  wanting: string;
  wantingType: 'item' | 'coins';
  wantingValue?: number;
  welcomeLetter?: string;
  status: 'open' | 'accepted' | 'declined';
  messages: { id: string; senderId: string; senderName: string; content: string; timestamp: string }[];
}

interface BarterHistory {
  id: string;
  fromUser: string;
  toUser: string;
  offering: string;
  wanting: string;
  completedAt: string;
}

// Item counts for mock data
const itemCounts: Record<string, number> = {
  '1': 2, // Emerald x2
  '2': 1, // Ruby x1
  '4': 3, // Sapphire x3
  '6': 2, // Topaz x2
  '8': 1, // Pearl x1
};

// All available items for selection
const allItems = [
  { id: 'coins', name: 'Coins', rarity: 'currency', value: 0 },
  ...mockCosmetics.map(c => ({
    id: c.id,
    name: c.name,
    rarity: c.rarity,
    value: itemValues[c.rarity] || 50,
  })),
];

const BarterPage = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedOffering, setSelectedOffering] = useState('');
  const [wantedType, setWantedType] = useState<'item' | 'coins'>('item');
  const [wantedItem, setWantedItem] = useState('');
  const [wantedCoins, setWantedCoins] = useState(0);
  const [welcomeLetter, setWelcomeLetter] = useState('');
  const [chatOfferId, setChatOfferId] = useState<string | null>(null);
  const [chatMessage, setChatMessage] = useState('');
  const [activeTab, setActiveTab] = useState<'offers' | 'history'>('offers');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const ownedCosmetics = mockCosmetics.filter(c => c.owned && !c.equipped);
  
  const [offers, setOffers] = useState<TradeOffer[]>([
    { 
      id: '1', 
      fromUser: 'Sarah W.', 
      fromUserId: '2', 
      fromAvatarLetter: 'S',
      offering: 'Ruby', 
      offeringId: 'c1', 
      offeringRarity: 'epic',
      offeringValue: 300,
      wanting: 'Diamond', 
      wantingType: 'item',
      welcomeLetter: 'Hello guys, here\'s a duplicate from me! Open to negotiate 😊',
      status: 'open',
      messages: [
        { id: '1', senderId: '2', senderName: 'Sarah W.', content: 'Feel free to offer something else!', timestamp: '10:30 AM' }
      ]
    },
    { 
      id: '2', 
      fromUser: 'James C.', 
      fromUserId: '3', 
      fromAvatarLetter: 'J',
      offering: 'Sapphire', 
      offeringId: 'c2', 
      offeringRarity: 'rare',
      offeringValue: 150,
      wanting: 'Emerald', 
      wantingType: 'item',
      status: 'open',
      messages: []
    },
    { 
      id: '3', 
      fromUser: 'Maya J.', 
      fromUserId: '4', 
      fromAvatarLetter: 'M',
      offering: 'Amethyst', 
      offeringId: 'c3', 
      offeringRarity: 'epic',
      offeringValue: 300,
      wanting: '200 Coins', 
      wantingType: 'coins',
      wantingValue: 200,
      welcomeLetter: 'Trading my Amethyst! Let me know what you have.',
      status: 'open',
      messages: []
    },
  ]);

  const [history, setHistory] = useState<BarterHistory[]>([]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (chatOfferId) {
      scrollToBottom();
    }
  }, [chatOfferId, offers]);

  const getSelectedItemValue = () => {
    const item = ownedCosmetics.find(c => c.id === selectedOffering);
    return item ? itemValues[item.rarity] || 50 : 0;
  };

  const handleCreateOffer = () => {
    if (!selectedOffering) {
      toast.error('Please select an item to offer');
      return;
    }
    
    if (wantedType === 'item' && !wantedItem) {
      toast.error('Please select an item you want');
      return;
    }

    if (wantedType === 'coins') {
      const maxCoins = getSelectedItemValue();
      if (wantedCoins <= 0 || wantedCoins >= maxCoins) {
        toast.error(`Coins must be between 1 and ${maxCoins - 1} (below item value)`);
        return;
      }
    }
    
    const cosmetic = ownedCosmetics.find(c => c.id === selectedOffering);
    if (!cosmetic) return;

    const wantedDisplay = wantedType === 'coins' 
      ? `${wantedCoins} Coins` 
      : allItems.find(i => i.id === wantedItem)?.name || wantedItem;

    const newOffer: TradeOffer = {
      id: Date.now().toString(),
      fromUser: user?.username || 'You',
      fromUserId: user?.id || '1',
      fromAvatarLetter: user?.avatarLetter || 'U',
    offering: cosmetic.name,
    offeringId: cosmetic.id,
    offeringRarity: cosmetic.rarity,
    offeringValue: itemValues[cosmetic.rarity] || 50,
    wanting: wantedDisplay,
    wantingType: wantedType,
    wantingValue: wantedType === 'coins' ? wantedCoins : undefined,
      welcomeLetter: welcomeLetter || undefined,
      status: 'open',
      messages: [],
    };

    setOffers(prev => [newOffer, ...prev]);
    setSelectedOffering('');
    setWantedItem('');
    setWantedCoins(0);
    setWelcomeLetter('');
    setIsCreateOpen(false);
    toast.success('Trade offer created!');
  };

  const handleAcceptOffer = (offerId: string) => {
    const offer = offers.find(o => o.id === offerId);
    if (!offer) return;

    // Move to history
    const historyEntry: BarterHistory = {
      id: Date.now().toString(),
      fromUser: offer.fromUser,
      toUser: user?.username || 'You',
      offering: offer.offering,
      wanting: offer.wanting,
      completedAt: new Date().toISOString(),
    };

    setHistory(prev => [historyEntry, ...prev]);
    
    // Remove from offers
    setOffers(prev => prev.filter(o => o.id !== offerId));
    
    toast.success('Trade accepted! Items have been exchanged.');
  };

  const handleDeclineOffer = (offerId: string) => {
    setOffers(prev => prev.filter(o => o.id !== offerId));
    toast.info('Trade offer declined');
  };

  const handleSendMessage = () => {
    if (!chatMessage.trim() || !chatOfferId || !user) return;

    setOffers(prev => prev.map(o => {
      if (o.id === chatOfferId) {
        return {
          ...o,
          messages: [
            ...o.messages,
            {
              id: Date.now().toString(),
              senderId: user.id,
              senderName: user.username,
              content: chatMessage,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            }
          ]
        };
      }
      return o;
    }));
    setChatMessage('');
  };

  const filteredOffers = offers.filter(o => 
    o.status === 'open' &&
    (o.offering.toLowerCase().includes(searchQuery.toLowerCase()) ||
    o.wanting.toLowerCase().includes(searchQuery.toLowerCase()) ||
    o.fromUser.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const myOffers = offers.filter(o => o.fromUserId === user?.id);
  const currentChatOffer = offers.find(o => o.id === chatOfferId);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <RefreshCw className="h-8 w-8 text-primary" />
          <div>
            <h1 className="font-display text-3xl font-bold">Barter</h1>
            <p className="text-muted-foreground">Trade items with other students</p>
          </div>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gradient-primary">
              <Plus className="h-4 w-4 mr-2" />
              Create Offer
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Trade Offer</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Item You're Offering</Label>
                <Select value={selectedOffering} onValueChange={setSelectedOffering}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an item" />
                  </SelectTrigger>
                  <SelectContent>
                    {ownedCosmetics.map(c => (
                      <SelectItem key={c.id} value={c.id}>
                        <div className="flex items-center gap-2">
                          <span>{c.name}</span>
                          <Badge variant="secondary" className="text-xs">{c.rarity}</Badge>
                          <span className="text-muted-foreground flex items-center gap-1">
                            <Gem className="h-3 w-3" />
                            {itemValues[c.rarity] || 50}
                          </span>
                          <span className="text-muted-foreground">x{itemCounts[c.id] || 1}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedOffering && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    Value: <Gem className="h-3 w-3" /> {getSelectedItemValue()}
                  </p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label>What do you want?</Label>
                <Select value={wantedType} onValueChange={(v) => setWantedType(v as 'item' | 'coins')}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="item">Another Item</SelectItem>
                    <SelectItem value="coins">Coins</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {wantedType === 'item' ? (
                <div className="space-y-2">
                  <Label>Select Item</Label>
                  <Select value={wantedItem} onValueChange={setWantedItem}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select an item" />
                    </SelectTrigger>
                    <SelectContent>
                      {allItems.filter(i => i.id !== 'coins').map(item => (
                        <SelectItem key={item.id} value={item.id}>
                          <div className="flex items-center gap-2">
                            <span>{item.name}</span>
                            <Badge variant="secondary" className="text-xs">{item.rarity}</Badge>
                            <span className="text-muted-foreground flex items-center gap-1">
                              <Gem className="h-3 w-3" />
                              {item.value}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label>Coins Amount (must be below item value: {getSelectedItemValue()})</Label>
                  <Input
                    type="number"
                    min={1}
                    max={getSelectedItemValue() - 1}
                    value={wantedCoins}
                    onChange={(e) => setWantedCoins(parseInt(e.target.value) || 0)}
                    placeholder="Enter amount..."
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label>Welcome Letter (Optional)</Label>
                <Textarea
                  value={welcomeLetter}
                  onChange={(e) => setWelcomeLetter(e.target.value)}
                  placeholder="Write a message to potential traders..."
                  rows={3}
                />
              </div>
              
              <Button onClick={handleCreateOffer} className="w-full gradient-primary">
                <Plus className="h-4 w-4 mr-2" />
                Create Offer
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        <Button
          variant={activeTab === 'offers' ? 'default' : 'outline'}
          onClick={() => setActiveTab('offers')}
          className={activeTab === 'offers' ? 'gradient-primary' : ''}
        >
          Active Offers
        </Button>
        <Button
          variant={activeTab === 'history' ? 'default' : 'outline'}
          onClick={() => setActiveTab('history')}
          className={activeTab === 'history' ? 'gradient-primary' : ''}
        >
          <Clock className="h-4 w-4 mr-2" />
          History ({history.length})
        </Button>
      </div>

      {activeTab === 'offers' ? (
        <>
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search offers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Your Items */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-display">Your Items for Trade</CardTitle>
            </CardHeader>
            <CardContent>
              {ownedCosmetics.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">No items available for trade</p>
              ) : (
                <div className="flex gap-4 overflow-x-auto pb-2">
                  {ownedCosmetics.map(cosmetic => (
                    <div key={cosmetic.id} className="flex-shrink-0 w-32 p-3 rounded-lg bg-secondary/30">
                      <div className="aspect-square rounded-lg bg-secondary/50 mb-2 flex items-center justify-center">
                        <Sparkles className="h-6 w-6 text-primary/50" />
                      </div>
                      <p className="text-xs font-medium truncate">{cosmetic.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{cosmetic.rarity}</p>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-xs text-primary font-medium flex items-center gap-1">
                          <Gem className="h-3 w-3" />
                          {itemValues[cosmetic.rarity] || 50}
                        </span>
                        <span className="text-xs text-muted-foreground">x{itemCounts[cosmetic.id] || 1}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* My Offers */}
          {myOffers.length > 0 && (
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="font-display">Your Active Offers</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {myOffers.map(offer => (
                  <div key={offer.id} className="flex items-center gap-4 p-4 rounded-lg bg-primary/10 border border-primary/30">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <div className="px-3 py-2 rounded-lg bg-secondary">
                          <span className="font-medium text-sm">{offer.offering}</span>
                          <span className="text-xs text-muted-foreground ml-2 flex items-center gap-1 inline-flex">
                            <Gem className="h-3 w-3" />
                            {offer.offeringValue}
                          </span>
                        </div>
                        <ArrowRight className="h-4 w-4 text-muted-foreground" />
                        <div className="px-3 py-2 rounded-lg bg-secondary">
                          <span className="font-medium text-sm">{offer.wanting}</span>
                        </div>
                      </div>
                    </div>
                    <Badge variant="secondary">Open</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Active Offers from Others */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-display flex items-center gap-2">
                <Users className="h-5 w-5" />
                Active Offers
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {filteredOffers.filter(o => o.fromUserId !== user?.id).length === 0 ? (
                <p className="text-muted-foreground text-center py-4">No offers available</p>
              ) : (
                filteredOffers.filter(o => o.fromUserId !== user?.id).map(offer => (
                  <div key={offer.id} className="p-4 rounded-lg bg-secondary/30">
                    <div className="flex items-start gap-4 mb-3">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {offer.fromAvatarLetter}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium">{offer.fromUser} offers:</p>
                        {offer.welcomeLetter && (
                          <p className="text-sm text-muted-foreground italic mt-1">"{offer.welcomeLetter}"</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3 mb-4">
                      <div className="px-3 py-2 rounded-lg bg-secondary">
                        <span className="font-medium">{offer.offering}</span>
                        <Badge variant="secondary" className="ml-2 text-xs">{offer.offeringRarity}</Badge>
                        <span className="text-xs text-muted-foreground ml-2 flex items-center gap-1 inline-flex">
                          <Gem className="h-3 w-3" />
                          {offer.offeringValue}
                        </span>
                      </div>
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      <div className="px-3 py-2 rounded-lg bg-secondary">
                        <span className="font-medium">{offer.wanting}</span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        className="gradient-success"
                        onClick={() => handleAcceptOffer(offer.id)}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        Accept
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleDeclineOffer(offer.id)}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Decline
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => setChatOfferId(offer.id)}
                      >
                        <MessageCircle className="h-4 w-4 mr-1" />
                        Negotiate
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </>
      ) : (
        /* History Tab */
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Trade History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {history.length === 0 ? (
              <div className="text-center py-8">
                <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No completed trades yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {history.map(trade => (
                  <div key={trade.id} className="p-4 rounded-lg bg-secondary/30">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge className="bg-success/20 text-success">Completed</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(trade.completedAt), 'MMM d, yyyy')} at {format(new Date(trade.completedAt), 'h:mm a')}
                      </p>
                    </div>
                    <p className="text-sm">
                      <span className="font-medium">{trade.fromUser}</span> traded{' '}
                      <span className="text-primary font-medium">{trade.offering}</span> with{' '}
                      <span className="font-medium">{trade.toUser}</span> for{' '}
                      <span className="text-primary font-medium">{trade.wanting}</span>
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Negotiation Chat Dialog */}
      <Dialog open={!!chatOfferId} onOpenChange={() => setChatOfferId(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Negotiate with {currentChatOffer?.fromUser}</DialogTitle>
          </DialogHeader>
          {currentChatOffer && (
            <div className="space-y-4">
              <div className="p-3 rounded-lg bg-secondary/30">
                <p className="text-sm text-muted-foreground">Current offer:</p>
                <p className="font-medium">{currentChatOffer.offering} → {currentChatOffer.wanting}</p>
              </div>

              <ScrollArea className="h-64 border rounded-lg p-4">
                <div className="space-y-3">
                  {currentChatOffer.messages.length === 0 ? (
                    <p className="text-center text-muted-foreground text-sm">Start the negotiation...</p>
                  ) : (
                    currentChatOffer.messages.map(msg => (
                      <div 
                        key={msg.id}
                        className={`flex gap-2 ${msg.senderId === user?.id ? 'flex-row-reverse' : ''}`}
                      >
                        <Avatar className="h-8 w-8 flex-shrink-0">
                          <AvatarFallback className="text-xs">
                            {msg.senderName.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className={`max-w-[70%] ${msg.senderId === user?.id ? 'text-right' : ''}`}>
                          <div className={`inline-block p-2 rounded-lg ${
                            msg.senderId === user?.id 
                              ? 'bg-primary text-primary-foreground' 
                              : 'bg-secondary'
                          }`}>
                            <p className="text-sm">{msg.content}</p>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{msg.timestamp}</p>
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              <div className="flex gap-2">
                <Input
                  placeholder="Type your message..."
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                />
                <Button onClick={handleSendMessage} className="gradient-primary">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BarterPage;