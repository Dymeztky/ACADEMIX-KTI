import { useState } from 'react';
import { mockFriends } from '@/lib/mockData';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Users, UserPlus, Search, MessageCircle, Check, X } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import type { Friend } from '@/types';

// Mock all users for search
const mockAllUsers = [
  ...mockFriends,
  { id: '10', username: 'Emma Wilson', handle: '@emmaw', avatarLetter: 'E', level: 21, status: 'offline' as const, grade: '12' as const, class: 'C' as const },
  { id: '11', username: 'Lucas Brown', handle: '@lucasb', avatarLetter: 'L', level: 20, status: 'online' as const, grade: '11' as const, class: 'A' as const },
  { id: '12', username: 'Sophia Davis', handle: '@sophiad', avatarLetter: 'S', level: 19, status: 'offline' as const, grade: '11' as const, class: 'B' as const },
  { id: '13', username: 'Noah Miller', handle: '@noahm', avatarLetter: 'N', level: 18, status: 'online' as const, grade: '10' as const, class: 'A' as const },
  { id: '14', username: 'Olivia Garcia', handle: '@oliviag', avatarLetter: 'O', level: 22, status: 'offline' as const, grade: '12' as const, class: 'B' as const },
];

interface FriendRequest {
  id: string;
  userId: string;
  username: string;
  avatarLetter: string;
  status: 'pending' | 'sent';
  level: number;
  grade: string;
  class: string;
}

const FriendsPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([
    { id: '1', userId: '10', username: 'Emma Wilson', avatarLetter: 'E', status: 'pending', level: 21, grade: '12', class: 'C' },
  ]);
  const [sentRequests, setSentRequests] = useState<string[]>([]);
  const [friends, setFriends] = useState<Friend[]>(mockFriends);
  const navigate = useNavigate();

  const friendIds = friends.map(f => f.id);
  
  // Search results - exclude existing friends
  const searchResults = searchQuery.length > 0
    ? mockAllUsers.filter(u => 
        !friendIds.includes(u.id) &&
        (u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.handle.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  const handleMessage = (friendId: string) => {
    navigate(`/chat?user=${friendId}`);
  };

  const handleViewProfile = (friendId: string) => {
    navigate(`/profile/${friendId}`);
  };

  const handleSendRequest = (userId: string, username: string, avatarLetter: string) => {
    if (sentRequests.includes(userId)) return;
    
    setSentRequests(prev => [...prev, userId]);
    toast.success(`Friend request sent to ${username}!`);
  };

  const handleAcceptRequest = (request: FriendRequest) => {
    // Add to friends list
    const newFriend: Friend = {
      id: request.userId,
      username: request.username,
      handle: `@${request.username.toLowerCase().replace(/\s/g, '')}`,
      avatarLetter: request.avatarLetter,
      level: request.level,
      status: 'offline',
      grade: request.grade as any,
      class: request.class as any,
    };
    
    setFriends(prev => [...prev, newFriend]);
    setFriendRequests(prev => prev.filter(r => r.id !== request.id));
    toast.success(`${request.username} is now your friend!`);
  };

  const handleDeclineRequest = (requestId: string) => {
    setFriendRequests(prev => prev.filter(r => r.id !== requestId));
    toast.info('Friend request declined');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="h-8 w-8 text-primary" />
          <div>
            <h1 className="font-display text-3xl font-bold">Friends</h1>
            <p className="text-muted-foreground">Manage friendships and challenge friends to Grim Reaper</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="friends" className="w-full">
        <TabsList className="bg-secondary/50">
          <TabsTrigger value="friends" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Friends ({friends.length})
          </TabsTrigger>
          <TabsTrigger value="requests" className="flex items-center gap-2">
            <UserPlus className="h-4 w-4" />
            Requests ({friendRequests.length})
          </TabsTrigger>
          <TabsTrigger value="search" className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            Find Friends
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="friends" className="mt-6">
          {/* Friends List */}
          <Card className="bg-card border-border">
            <CardContent className="p-6">
              {friends.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {friends.map((friend) => (
                    <div key={friend.id} className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30">
                      <button 
                        onClick={() => handleViewProfile(friend.id)}
                        className="relative hover:opacity-80 transition-opacity"
                      >
                        <Avatar className="h-14 w-14">
                          <AvatarFallback className="bg-primary text-primary-foreground font-semibold text-lg">
                            {friend.avatarLetter}
                          </AvatarFallback>
                        </Avatar>
                        <div className={`absolute bottom-0 right-0 h-4 w-4 rounded-full border-2 border-card ${
                          friend.status === 'online' ? 'bg-success' : 'bg-muted'
                        }`} />
                      </button>
                      
                      <div className="flex-1">
                        <button 
                          onClick={() => handleViewProfile(friend.id)}
                          className="hover:text-primary transition-colors"
                        >
                          <h3 className="font-semibold text-left">{friend.username}</h3>
                        </button>
                        <p className="text-sm text-muted-foreground">{friend.handle}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-muted-foreground">
                            Grade {friend.grade} {friend.class}
                          </span>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-primary font-medium">Level {friend.level}</span>
                        </div>
                      </div>
                      
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => handleMessage(friend.id)}
                      >
                        <MessageCircle className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center">
                  <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-semibold text-lg mb-2">No friends yet</h3>
                  <Button className="gradient-primary">
                    Find Friends
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="requests" className="mt-6">
          <Card className="bg-card border-border">
            <CardContent className="p-6">
              {friendRequests.length > 0 ? (
                <div className="space-y-4">
                  {friendRequests.map((request) => (
                    <div key={request.id} className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-primary text-primary-foreground font-semibold">
                          {request.avatarLetter}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <h3 className="font-semibold">{request.username}</h3>
                        <p className="text-sm text-muted-foreground">Wants to be your friend</p>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button 
                          size="sm"
                          className="gradient-success"
                          onClick={() => handleAcceptRequest(request)}
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeclineRequest(request.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center">
                  <UserPlus className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-semibold text-lg mb-2">No pending requests</h3>
                  <p className="text-muted-foreground">Friend requests will appear here</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="search" className="mt-6">
          <div className="space-y-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by username or handle..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            <Card className="bg-card border-border">
              <CardContent className="p-6">
                {searchQuery ? (
                  searchResults.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {searchResults.map((user) => (
                        <div key={user.id} className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30">
                          <button onClick={() => handleViewProfile(user.id)}>
                            <Avatar className="h-12 w-12 hover:opacity-80 transition-opacity">
                              <AvatarFallback className="bg-primary text-primary-foreground font-semibold">
                                {user.avatarLetter}
                              </AvatarFallback>
                            </Avatar>
                          </button>
                          
                          <div className="flex-1">
                            <button 
                              onClick={() => handleViewProfile(user.id)}
                              className="hover:text-primary transition-colors"
                            >
                              <h3 className="font-semibold text-left">{user.username}</h3>
                            </button>
                            <p className="text-sm text-muted-foreground">{user.handle}</p>
                            <p className="text-xs text-muted-foreground">
                              Grade {user.grade} {user.class} • Level {user.level}
                            </p>
                          </div>
                          
                          <Button 
                            variant={sentRequests.includes(user.id) ? 'secondary' : 'outline'}
                            size="sm"
                            onClick={() => handleSendRequest(user.id, user.username, user.avatarLetter)}
                            disabled={sentRequests.includes(user.id)}
                          >
                            {sentRequests.includes(user.id) ? (
                              <>
                                <Check className="h-4 w-4 mr-2" />
                                Sent
                              </>
                            ) : (
                              <>
                                <UserPlus className="h-4 w-4 mr-2" />
                                Add
                              </>
                            )}
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-12 text-center">
                      <Search className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                      <h3 className="font-semibold text-lg mb-2">No users found</h3>
                      <p className="text-muted-foreground">Try a different search term</p>
                    </div>
                  )
                ) : (
                  <div className="py-12 text-center">
                    <Search className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="font-semibold text-lg mb-2">Search for users</h3>
                    <p className="text-muted-foreground">Enter a username or handle to find friends</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FriendsPage;