import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { mockLeaderboard, mockSubjectGrades, calculateAverageScore, mockCosmetics, itemValues, mockFriends } from '@/lib/mockData';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Trophy, Flame, Coins, Users, BarChart3, Gem, MessageCircle, EyeOff } from 'lucide-react';

// Generate mock subject scores for other users based on their average
const generateUserScores = (averageScore: number) => {
  const subjects = ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'IT'];
  return subjects.map(subject => {
    const variance = Math.floor(Math.random() * 10) - 5;
    return {
      subject,
      score: Math.min(100, Math.max(0, Math.round(averageScore + variance))),
    };
  });
};

// All users for profile lookup
const getAllUsers = () => {
  // Combine mockLeaderboard with mockFriends for comprehensive user lookup
  const allUsers = [
    ...mockLeaderboard.map(u => ({
      id: u.userId,
      username: u.username,
      avatarLetter: u.avatarLetter,
      level: u.level,
      rank: u.rank,
      averageScore: u.averageScore,
    })),
    ...mockFriends.map(f => ({
      id: f.id,
      username: f.username,
      avatarLetter: f.avatarLetter,
      level: f.level,
      rank: 0,
      averageScore: 80,
    })),
  ];
  
  // Remove duplicates by id
  const uniqueUsers = allUsers.reduce((acc, user) => {
    if (!acc.find(u => u.id === user.id)) {
      acc.push(user);
    }
    return acc;
  }, [] as typeof allUsers);
  
  return uniqueUsers;
};

const ProfilePage = () => {
  const { userId } = useParams();
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();
  
  const isOwnProfile = !userId || userId === currentUser?.id;
  
  // Find user from all possible sources
  const allUsers = getAllUsers();
  const foundUser = allUsers.find(u => u.id === userId);
  const leaderboardUser = mockLeaderboard.find(u => u.userId === userId);
  const friendUser = mockFriends.find(f => f.id === userId);

  // Get privacy settings
  const showSubjectScores = localStorage.getItem('academix_show_subject_scores') !== 'false';
  
  // Build user data
  const userData = isOwnProfile ? currentUser : foundUser ? {
    id: foundUser.id,
    username: foundUser.username,
    avatarLetter: foundUser.avatarLetter,
    level: foundUser.level,
    rank: foundUser.rank || leaderboardUser?.rank || 0,
    averageScore: foundUser.averageScore || leaderboardUser?.averageScore || 80,
    xp: 450 + (foundUser.level * 50),
    xpToNextLevel: 1000,
    coins: 500 + (foundUser.level * 25),
    streak: Math.floor(Math.random() * 14) + 1,
    class: friendUser?.class || 'A',
    grade: friendUser?.grade || '12',
    handle: `@${foundUser.username.toLowerCase().replace(/\s/g, '')}`,
    friendCount: Math.floor(Math.random() * 30) + 10,
    showSubjectScores: Math.random() > 0.3, // 70% show scores for other users
  } : null;

  if (!userData) {
    return (
      <div className="space-y-6 animate-fade-in">
        <Link to="/dashboard">
          <Button variant="ghost" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </Link>
        <div className="text-center py-12">
          <p className="text-muted-foreground">User not found</p>
        </div>
      </div>
    );
  }

  const xpProgress = ((userData.xp || 0) / (userData.xpToNextLevel || 1000)) * 100;
  
  // Use correct average calculation for own profile, or the user's average for others
  const averageScore = isOwnProfile 
    ? calculateAverageScore(mockSubjectGrades) 
    : Math.round((userData as any)?.averageScore || 75);
  
  // Generate subject scores for other users
  const subjectScores = isOwnProfile 
    ? mockSubjectGrades.map(g => ({ subject: g.subject, score: g.currentScore }))
    : generateUserScores(averageScore);
  
  // Calculate total item value
  const ownedItems = mockCosmetics.filter(c => c.owned);
  const totalItemValue = isOwnProfile 
    ? ownedItems.reduce((sum, item) => sum + (itemValues[item.rarity] || 50), 0)
    : Math.floor(Math.random() * 1000) + 200;

  const handleMessage = () => {
    if (!isOwnProfile && userData) {
      navigate(`/chat?user=${userData.id}`);
    }
  };

  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <Button variant="ghost" className="mb-4" onClick={handleBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        
        {!isOwnProfile && (
          <Button onClick={handleMessage} className="gradient-primary">
            <MessageCircle className="h-4 w-4 mr-2" />
            Message
          </Button>
        )}
      </div>

      {/* Profile Header */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <div className="relative">
              <Avatar className="h-24 w-24 avatar-ring">
                <AvatarFallback className="bg-primary text-primary-foreground font-display font-bold text-4xl">
                  {userData.avatarLetter || (userData as any).username?.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-2 -right-2 level-badge h-10 w-10 rounded-full flex items-center justify-center">
                <span className="font-display font-bold text-primary-foreground">{userData.level || 1}</span>
              </div>
            </div>
            
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <h1 className="font-display text-2xl font-bold">{(userData as any).username}</h1>
                <span className="px-3 py-1 rounded-full bg-primary text-primary-foreground text-sm font-semibold">
                  Level {userData.level || 1}
                </span>
              </div>
              <p className="text-muted-foreground">Class {(userData as any).grade}{(userData as any).class}</p>
              <p className="text-muted-foreground text-sm">{(userData as any).handle || '@user'}</p>
              
              <div className="mt-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">Experience</span>
                  <span className="text-sm text-primary">{userData.xp || 0} / {(userData as any).xpToNextLevel || 1000} XP</span>
                </div>
                <Progress value={xpProgress} className="h-2" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4 text-center">
            <Trophy className="h-6 w-6 text-warning mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Rank</p>
            <p className="font-display font-bold text-2xl text-warning">#{(userData as any).rank || '-'}</p>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-4 text-center">
            <Flame className="h-6 w-6 text-destructive mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Streak</p>
            <p className="font-display font-bold text-2xl text-destructive">{(userData as any).streak || 0} days</p>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-4 text-center">
            <Coins className="h-6 w-6 text-warning mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Coins</p>
            <p className="font-display font-bold text-2xl text-warning">{(userData as any).coins?.toLocaleString() || 0}</p>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-4 text-center">
            <Users className="h-6 w-6 text-primary mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Friends</p>
            <p className="font-display font-bold text-2xl text-primary">
              {isOwnProfile 
                ? (currentUser?.friendsCount || 0) 
                : ((userData as any).friendCount || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4 text-center">
            <Gem className="h-6 w-6 text-purple-400 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Item Value</p>
            <p className="font-display font-bold text-2xl text-purple-400">{totalItemValue}</p>
          </CardContent>
        </Card>
      </div>

      {/* Academic Performance */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="h-5 w-5 text-primary" />
            <h3 className="font-display text-lg font-bold">Academic Performance</h3>
          </div>
          
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground mb-2">Average Score</p>
            <p className="font-display text-5xl font-bold text-primary">{averageScore}</p>
          </div>
          
          {/* Show subject grades based on privacy setting */}
          {(isOwnProfile || (userData as any).showSubjectScores !== false) ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-6">
              {subjectScores.map(g => (
                <div key={g.subject} className="p-3 rounded-lg bg-secondary/30">
                  <p className="text-xs text-muted-foreground">{g.subject}</p>
                  <p className="font-display font-bold text-xl">{g.score}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-6 p-4 rounded-lg bg-secondary/30 text-center">
              <EyeOff className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">Subject scores are hidden</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfilePage;