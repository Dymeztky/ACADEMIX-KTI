import React, { createContext, useContext, useState, useEffect } from 'react';
import type { Subject } from '@/types';

interface SubjectTarget {
  subject: Subject;
  target: number;
}

interface TargetContextType {
  targets: SubjectTarget[];
  setTarget: (subject: Subject, target: number) => void;
  getTarget: (subject: Subject) => number;
}

const defaultTargets: SubjectTarget[] = [
  { subject: 'Mathematics', target: 85 },
  { subject: 'Physics', target: 85 },
  { subject: 'Chemistry', target: 90 },
  { subject: 'Biology', target: 85 },
  { subject: 'English', target: 80 },
  { subject: 'IT', target: 85 },
];

const TargetContext = createContext<TargetContextType | undefined>(undefined);

export const TargetProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [targets, setTargets] = useState<SubjectTarget[]>(() => {
    const stored = localStorage.getItem('academix_targets');
    return stored ? JSON.parse(stored) : defaultTargets;
  });

  useEffect(() => {
    localStorage.setItem('academix_targets', JSON.stringify(targets));
  }, [targets]);

  const setTarget = (subject: Subject, target: number) => {
    setTargets(prev => prev.map(t => 
      t.subject === subject ? { ...t, target } : t
    ));
  };

  const getTarget = (subject: Subject): number => {
    return targets.find(t => t.subject === subject)?.target || 85;
  };

  return (
    <TargetContext.Provider value={{ targets, setTarget, getTarget }}>
      {children}
    </TargetContext.Provider>
  );
};

export const useTargets = () => {
  const context = useContext(TargetContext);
  if (!context) {
    throw new Error('useTargets must be used within a TargetProvider');
  }
  return context;
};
