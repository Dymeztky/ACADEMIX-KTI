import React, { createContext, useContext, useState, useEffect } from 'react';
import type { CalendarEvent, Subject } from '@/types';
import { mockEvents } from '@/lib/mockData';

interface ExtendedCalendarEvent extends CalendarEvent {
  notes?: string;
}

interface CalendarContextType {
  events: ExtendedCalendarEvent[];
  addEvent: (event: ExtendedCalendarEvent) => void;
  removeEvent: (id: string) => void;
  getUpcomingEvents: () => ExtendedCalendarEvent[];
}

const CalendarContext = createContext<CalendarContextType | undefined>(undefined);

export const CalendarProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [events, setEvents] = useState<ExtendedCalendarEvent[]>(() => {
    const stored = localStorage.getItem('academix_calendar_events');
    return stored ? JSON.parse(stored) : mockEvents;
  });

  useEffect(() => {
    localStorage.setItem('academix_calendar_events', JSON.stringify(events));
  }, [events]);

  const addEvent = (event: ExtendedCalendarEvent) => {
    setEvents(prev => [...prev, event]);
  };

  const removeEvent = (id: string) => {
    setEvents(prev => prev.filter(e => e.id !== id));
  };

  const getUpcomingEvents = (): ExtendedCalendarEvent[] => {
    const today = new Date();
    return events
      .filter(e => {
        const eventDate = new Date(e.date);
        return eventDate >= today;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  };

  return (
    <CalendarContext.Provider value={{ events, addEvent, removeEvent, getUpcomingEvents }}>
      {children}
    </CalendarContext.Provider>
  );
};

export const useCalendar = () => {
  const context = useContext(CalendarContext);
  if (!context) {
    throw new Error('useCalendar must be used within a CalendarProvider');
  }
  return context;
};
