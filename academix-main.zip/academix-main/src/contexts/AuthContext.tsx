import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User, UserRole } from '@/types';
import { mockUser } from '@/lib/mockData';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string, role: UserRole) => Promise<boolean>;
  signup: (email: string, password: string, username: string, role: UserRole, grade?: string, classLetter?: string) => Promise<boolean>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const storedUser = localStorage.getItem('academix_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string, role: UserRole): Promise<boolean> => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // For demo, use mock user
    const loggedInUser = { ...mockUser, email, role };
    setUser(loggedInUser);
    localStorage.setItem('academix_user', JSON.stringify(loggedInUser));
    setIsLoading(false);
    return true;
  };

  const signup = async (
    email: string, 
    password: string, 
    username: string, 
    role: UserRole,
    grade?: string,
    classLetter?: string
  ): Promise<boolean> => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser: User = {
      id: Date.now().toString(),
      username,
      handle: `@${username.toLowerCase().replace(/\s/g, '')}`,
      email,
      role,
      grade: grade as User['grade'],
      class: classLetter as User['class'],
      level: 1,
      xp: 0,
      xpToNextLevel: 100,
      coins: 100,
      rank: 999,
      streak: 0,
      friendsCount: 0,
      profileVisible: true,
      avatarLetter: username.charAt(0).toUpperCase(),
      createdAt: new Date().toISOString(),
    };
    
    setUser(newUser);
    localStorage.setItem('academix_user', JSON.stringify(newUser));
    setIsLoading(false);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('academix_user');
  };

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem('academix_user', JSON.stringify(updatedUser));
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      isLoading,
      login,
      signup,
      logout,
      updateUser,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
